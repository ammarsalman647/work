import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/photo.dart';

Widget wallpaper(List<PhotoMoodel> listPhotos, BuildContext context) {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 16),
    child: GridView.count(
      padding: EdgeInsets.all(4),
      crossAxisCount: 2,
      childAspectRatio: 0.6,
      mainAxisSpacing: 6,
      crossAxisSpacing: 6,
      children: listPhotos.map((PhotoMoodel photosModel) {
        return GridTile(child: Hero(tag: photosModel.src!.portrait!, child: Container(
                  child:
                      CachedNetworkImage(imageUrl: photosModel.src!.portrait!,fit: BoxFit.cover,),
                )));
      }).toList(),
    ),
  );
}
