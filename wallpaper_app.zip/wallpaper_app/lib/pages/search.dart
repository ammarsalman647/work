import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:wallpaper_app/models/photo.dart';
import 'package:wallpaper_app/widget/widget.dart';

class Search extends StatefulWidget {
  const Search({super.key});

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  List<PhotoMoodel> photos = [];
  TextEditingController searchcontroller = new TextEditingController();
  Future<void> getSearchWallpaper(String searchQuery) async {
    try{
      final response = await http.get(
        Uri.parse(
          'https://api.pexels.com/v1/search?query=$searchQuery&per_page=30',
        ),
        headers: {
          'Authorization': 'zZWb3tZEputoNoX5KtPRTL5l1PZWRyxmaqpybbKayHIlL2XxBhrkQpA7',
          // "Authorization":"xNEbSdi33s54r5TfUoEx6MkufnpINsqqlrD0yeaGzhIGmvofpkYjCXm"
        },
      );

      if (response.statusCode == 200) {
        print('successful');
        Map<String, dynamic> jsonData = jsonDecode(response.body);
        jsonData["photos"].forEach((element) {
          PhotoMoodel photosModel = PhotoMoodel.fromMap(element);
          photos.add(photosModel);
        });
        setState(() {});
      } else {
        print('Failed to load data: ${response.statusCode}');
      }
    }catch(e){
      print('catcherror ${e.toString()}');
    }

  }
  // getSearchWallpaper(String searchQuery) async {
  //   await http.get(
  //       Uri.parse(
  //
  //           'https://api.pexels.com/v1/search?query=$searchQuery&per_page=30'),
  //       headers: {
  //         "Authorization":
  //             "zZWb3tZEputoNoX5KtPRTL5l1PZWRyxmaqpybbKayHIlL2XxBhrkQpA7",
  //       }).then((value) {
  //     Map<String, dynamic> jsonData = jsonDecode(value.body);
  //
  //         print('jsonvalue ${jsonData}');
  //     jsonData["photos"].forEach((element) {
  //       PhotosModel photosModel = new PhotosModel();
  //       photosModel = PhotosModel.fromMap(element);
  //       photos.add(photosModel);
  //     });
  //     setState(() {});
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Column(
          children: [
            Center(
              child: Padding(
                padding: EdgeInsets.only(top: 30, bottom: 10),
                child: Text(
                  'Search',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Poppins',
                      fontSize: 25),
                ),
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  color: Color(0xFFececf8),
                  borderRadius: BorderRadius.circular(20)),
              child: Padding(
                padding: const EdgeInsets.only(right: 10,left: 10),
                child: TextFormField(
                  controller: TextEditingController(),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      suffixIcon: GestureDetector(
                        onTap: () => getSearchWallpaper(searchcontroller.text),
                        child: Icon(
                          Icons.search_outlined,
                          color: Color.fromARGB(255, 84, 87, 93),
                        ),
                      )),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Expanded(child: wallpaper(photos, context))
          ],
        ),
    );
  }
}
