import 'package:flutter/material.dart';

class Black extends StatefulWidget {
  const Black({super.key});

  @override
  State<Black> createState() => _BlackState();
}

class _BlackState extends State<Black> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.red,
      ),
    );
  }
}
