
import 'package:flutter_screen_lock/flutter_screen_lock.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class More extends StatefulWidget {
  const More({super.key});

  @override
  State<More> createState() => _MoreState();
}

class _MoreState extends State<More> {

  final pin = Hive.box('pin');

  Future<void> createPin() async {
    Navigator.pop(context);
    final controller = await InputController();
    screenLockCreate(
      context: context,
      inputController: controller,
      onConfirmed: (matchedText) =>
      {pin.put('pin', matchedText), Navigator.of(context).pop(), Navigator.of(context).pop},
      canCancel: false,
      footer: TextButton(
        onPressed: () {
          controller.unsetConfirmed();
        },
        child: const Text('Reset input'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Image.asset(
              "assets/images/line.png",
              width: MediaQuery.of(context).size.width,
              fit: BoxFit.fitWidth,
            ),
            Column(
              children: [
                SizedBox(
                height: MediaQuery.of(context).size.height * 0.045,
              ),
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: MediaQuery.of(context).size.width * 0.05,
                      ),
                  child: Row(
                    children: [
                      Expanded(
                          flex: 1,
                          child: Container(
                            height: 30,
                          )
                          ),
                      const Expanded(
                        flex: 2,
                        child: Center(
                          child: Text(
                            "More",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                            ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.03,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.3,
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height * 0.03),
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20))),
                  child: Column(
                    children: [
                      ListTile(
                        dense: true,
                        minLeadingWidth: 15,
                        leading: Icon(
                          Icons.pin,
                          color: Colors.red,
                          size: 22,
                        ),
                        title: const Text(
                          'Change Passcode',
                          style: TextStyle(
                              fontSize: 17.0, fontWeight: FontWeight.bold),
                          textAlign: TextAlign.left,
                        ),
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) {
                              return ScreenLock(
                                title: Text("Enter Current Passcode"),
                                correctString: pin.get('pin'),
                                onCancelled: Navigator.of(context).pop,
                                onUnlocked: (){
                                  createPin();
                                },
                              );
                            },
                          );
                        },
                      ),
                      ListTile(
                        dense: true,
                        minLeadingWidth: 15,
                        leading: Icon(
                          Icons.privacy_tip,
                          color: Colors.green,
                          size: 22,
                        ),
                        title: const Text(
                          'Privacy Policy',
                          style: TextStyle(
                              fontSize: 17.0, fontWeight: FontWeight.bold),
                          textAlign: TextAlign.left,
                        ),
                        onTap: ()async {
                          var uri = Uri.parse('https://www.sherazihealthinnovations.org/bladder-bud');
                          await launchUrl(uri);
                        },
                      ),
                    ],
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

