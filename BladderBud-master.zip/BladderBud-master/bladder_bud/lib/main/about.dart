import 'package:flutter/material.dart';
import 'package:linkwell/linkwell.dart';
import 'dart:ui' as ui;

import 'package:url_launcher/url_launcher.dart';

class About extends StatefulWidget {
  const About({super.key});

  @override
  State<About> createState() => _AboutState();
}

class _AboutState extends State<About> {



  var FAQ = [
    {
      'Question': 'I am interested in conducting a research study that incorporates this app.',
      'Answer': 'Please contact us at SheraziHealthInnovations@gmail.com or Ali.Sherazi@Dal.ca.'
    },
    {
      'Question': 'Where can I learn more about this app and find more information about the organization?',
      'Answer': 'Please visit us at https://www.sherazihealthinnovations.org/ or feel free to email SheraziHealthInnovations@gmail.com'
    },
    {
      'Question': 'Do you have a website?',
      'Answer': 'https://www.sherazihealthinnovations.org/'
    },
    {
      'Question': 'I am not receiving reminders. How can I fix this?',
      'Answer': 'You can check if your notification settings are on for the app by going to your phone settings.'
    },
    {
      'Question': 'How do I forward my diary information',
      'Answer': 'After your diary is completed, you can forward a pdf or excel file of the diary and share it via email or any other platform'
    },
    {
      'Question': 'I was late to add an entry. Can I change the time on my app to add this entry?',
      'Answer': 'You can change the time of the entry by clicking on the time on top right.'
    },
    {
      'Question': 'What is IPSS?',
      'Answer': 'IPSS is for males with lower urinary tract symptoms.'
    },
    {
      'Question': 'I am having trouble using the app/found an issue/have questions.',
      'Answer': 'Please contact us at SheraziHealthInnovations@gmail.com or Ali.Sherazi@Dal.ca'
    },
    {
      'Question': 'I found a bug. How do I report this?',
      'Answer': 'Please email us at SheraziHealthInnovations@gmail.com if you found a bug or are having an issue with using the app'
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Image.asset(
              "assets/images/line.png",
              width: MediaQuery.of(context).size.width,
              fit: BoxFit.fitWidth,
            ),
            Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.06,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: MediaQuery.of(context).size.width * 0.05,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                              //         padding: const EdgeInsets.all(12),
                              //         decoration: const BoxDecoration(
                              //             color: Colors.white, shape: BoxShape.circle),
                              //         child: SvgPicture.asset("assets/images/menu.svg")
                              //         // const Icon(
                              //         //   Icons.menu,
                              //         //   size: 22,
                              //         //   color: Color(0xFF0091FF),
                              //         // ),
                              ),
                        ),
                      ),
                      const Expanded(
                        flex: 1,
                        child: Center(
                          child: Text(
                            "Help",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                            //     padding: const EdgeInsets.all(12),
                            //     decoration: BoxDecoration(
                            //         color: Colors.white,
                            //         borderRadius: BorderRadius.circular(12)),
                            //     child: Center(
                            //       child: Text(
                            //         "${DateTime.now().day} ${monName(DateTime.now().month)}, ${DateTime.now().year}",
                            //         style: const TextStyle(
                            //             fontSize: 12,
                            //             fontWeight: FontWeight.w500,
                            //             color: Color(0xFF0091FF)),
                            //       ),
                            //     ),
                            ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.03,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height * 0.03,
                      right: MediaQuery.of(context).size.width * 0.05,
                      left: MediaQuery.of(context).size.width * 0.05),
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20))),
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.all(12),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: Color(0xFFF1F1F1)),
                        child: Column(
                          children: [
                            Text(
                              "About Us",
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w600),
                            ),
                            Divider(
                              color: Color(0xFF979797),
                            ),
                            LinkWell(
                              "The Bladder Bud is a tool to help people keep a voiding diary. It also serves as a timed voiding tool where you can add reminders about washroom visits or when to drink. Bladder Bud was created by Ali Sherazi, a medical student at Dalhousie University, who is passionate about improving outcomes for people struggling with urinary incontinence and other related issues. \nWebsite: \nsherazihealthinnovations.org",
                              style: TextStyle(
                                color: Colors.black87,
                                  fontSize: 16, fontWeight: FontWeight.w500),
                              textAlign: TextAlign.justify,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.02,
                      ),
                      Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: InkWell(
                              onTap: () {},
                              child: Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.05,
                                decoration: BoxDecoration(
                                    color: Color(0xFF0091FF),
                                    borderRadius: BorderRadius.circular(8)),
                                child: Center(
                                  child: Text(
                                    "Ask a Question?",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.02,
                      ),
                      Container(
                        padding: EdgeInsets.all(12),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: Color(0xFFF1F1F1)),
                        child: Column(
                          children: [
                            Text(
                              "FAQ’s",
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w600),
                            ),
                        ListView.builder(
                          shrinkWrap: true,
                          physics:
                          const NeverScrollableScrollPhysics(),
                          itemCount: FAQ.length,
                          // snapshot.data!.docs.length,
                          itemBuilder: (context, index) {
                            var data =
                            FAQ[index];
                            return Directionality(
                              textDirection: ui.TextDirection.ltr,
                              child: QA(
                                  question: data['Question'],
                                  answer: data['Answer']),
                            );
                          },
                          scrollDirection: Axis.vertical,
                        ),

                            // StreamBuilder<QuerySnapshot>(
                            //   stream:
                            //       firestore //------for select the item in the firestore----
                            //           .collection("FAQ")
                            //           .snapshots(),
                            //   builder: (BuildContext context,
                            //       AsyncSnapshot<QuerySnapshot> snapshot) {
                            //     if (!snapshot.hasData) {
                            //       return Container(
                            //           alignment: Alignment.topCenter,
                            //           margin: const EdgeInsets.only(top: 20),
                            //           child: const CircularProgressIndicator(
                            //             backgroundColor: Colors.grey,
                            //             color: Colors.blue,
                            //           ));
                            //     } else {
                            //       return ListView.builder(
                            //         shrinkWrap: true,
                            //         physics:
                            //             const NeverScrollableScrollPhysics(),
                            //         itemCount: snapshot.data!.docs.length,
                            //         // snapshot.data!.docs.length,
                            //         itemBuilder: (context, index) {
                            //           DocumentSnapshot data =
                            //               snapshot.data!.docs[index];
                            //           return Directionality(
                            //             textDirection: ui.TextDirection.ltr,
                            //             child: QA(
                            //                 question: data.get('Question'),
                            //                 answer: data.get('Answer')),
                            //           );
                            //         },
                            //         scrollDirection: Axis.vertical,
                            //       );
                            //     }
                            //   },
                            // ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class QA extends StatefulWidget {
  final question, answer;
  const QA({Key? key, this.question, this.answer}) : super(key: key);

  @override
  State<QA> createState() => _QAState();
}

class _QAState extends State<QA> {
  bool open = false;

  Uri? uri;

  @override
  void initState() {
    setState(() {
      uri = Uri.tryParse(widget.answer);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.6,
                    child: Text(
                      widget.question,
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF979797)),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      setState(() {
                        if (open == true) {
                          open = false;
                        } else {
                          open = true;
                        }
                      });
                    },
                    child: open
                        ? Icon(Icons.keyboard_arrow_up)
                        : Icon(Icons.keyboard_arrow_down),
                  )
                ],
              ),
              open == true
                  ?  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: LinkWell(
                    widget.answer,
                    style:  TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: Colors.black87),
                    linkStyle: TextStyle(color: Colors.blue,fontSize: 15, decoration: TextDecoration.underline)
              ),
                  )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }
}
