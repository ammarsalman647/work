// ignore_for_file: must_be_immutable

import 'package:bladder_bud/MCQ/ipss.dart';
import 'package:bladder_bud/diary/diary.dart';
import 'package:bladder_bud/drink/drink.dart';
import 'package:bladder_bud/pad/pad.dart';
import 'package:bladder_bud/washroom/washroom.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../SleepTime/wake_bed.dart';
import '../reminders/pages/home/reminder_main.dart';

class HomeScr extends StatefulWidget {
  const HomeScr({super.key});

  @override
  State<HomeScr> createState() => _HomeScrState();
}

class _HomeScrState extends State<HomeScr> {
  String monName(int mon) {
    switch (mon) {
      case 1:
        return "Jan";
      case 2:
        return "Feb";
      case 3:
        return "Mar";
      case 4:
        return "Apr";
      case 5:
        return "May";
      case 6:
        return "Jun";
      case 7:
        return "Jul";
      case 8:
        return "Aug";
      case 9:
        return "Sep";
      case 10:
        return "Oct";
      case 11:
        return "Nov";
      default:
        return "Dec";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Image.asset(
              "assets/images/line.png",
              width: MediaQuery.of(context).size.width,
              fit: BoxFit.fitWidth,
            ),
            Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.05,
                ),
                Padding(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 1,
                          child: SizedBox()),
                      const Expanded(
                        flex: 1,
                        child: Center(
                          child: Text(
                            "Home",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12)),
                          child: Center(
                            child: Text(
                              "${DateTime.now().day} ${monName(DateTime.now().month)}, ${DateTime.now().year}",
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  color: Color(0xFF0091FF)),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.02,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height * 0.03),
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20))),
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(
                            vertical:
                                MediaQuery.of(context).size.height * 0.02),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: ((context) => Diary())));
                          },
                          child: Image.asset(
                            "assets/images/middle.png",
                            height: MediaQuery.of(context).size.height * 0.3,
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          TabBox(
                            img: "toilet",
                            lab: "Add Washroom Visit/Leak",
                            scr: Washroom(),
                          ),
                          TabBox(
                            img: "glass",
                            lab: "Add Drink",
                            scr: Drink(),
                          )
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            TabBox(
                              img: "sanitary",
                              lab: "Add Pad Change",
                              scr: Pad(),
                            ),
                            TabBox(
                              img: "clock",
                              lab: "Add Wakeup/Bedtime",
                              scr: WakeBed(),
                            )
                          ],
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          TabBox(
                            img: "disease",
                            lab: "Add IPSS Questionare",
                            scr: ipss(),
                          ),
                          TabBox(
                            img: "bell",
                            lab: "Add Reminders",
                            scr: Index(),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class TabBox extends StatefulWidget {
  TabBox({Key? key, required this.img, required this.lab, required this.scr})
      : super(key: key);
  String img, lab;
  Widget scr;

  @override
  State<TabBox> createState() => _TabBoxState();
}

class _TabBoxState extends State<TabBox> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => widget.scr));
      },
      child: PhysicalModel(
        elevation: 1,
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.1,
          width: MediaQuery.of(context).size.width * 0.4,
          child: Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset("assets/images/${widget.img}.svg"),
                const SizedBox(
                  height: 8,
                ),
                Text(
                  widget.lab,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 12),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
