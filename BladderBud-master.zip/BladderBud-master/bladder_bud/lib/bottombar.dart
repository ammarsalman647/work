import 'package:bladder_bud/main/about.dart';
import 'package:bladder_bud/main/home.dart';
import 'package:bladder_bud/main/more.dart';
import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screen_lock/flutter_screen_lock.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ignore: must_be_immutable
class Bar extends StatefulWidget {
  Bar({Key? key}) : super(key: key);

  @override
  State<Bar> createState() => _BarState();
}

class _BarState extends State<Bar> {
  final List<Widget> screens = [
    HomeScr(),
    Container(),
    HomeScr(),
    About(),
    More(),
  ];
  final pin = Hive.box('pin');
  int ind = 0;

  final PageStorageBucket bucket = PageStorageBucket();

  Future<void> createPin() async {
    final controller = await InputController();
    screenLockCreate(
      context: context,
      inputController: controller,
      onConfirmed: (matchedText) =>
          {pin.put('pin', matchedText), Navigator.of(context).pop()},
      canCancel: false,
      footer: TextButton(
        onPressed: () {
          controller.unsetConfirmed();
        },
        child: const Text('Reset input'),
      ),
    );
  }

  Future<void> confirmPin() async {
    final controller = await InputController();
    screenLock(
      context: context,
      correctString: pin.get('pin'),
      maxRetries: 2,
      canCancel: false,
      retryDelay: const Duration(seconds: 3),
      delayBuilder: (context, delay) => Text(
        'Cannot be entered for ${(delay.inMilliseconds / 1000).ceil()} seconds.',
      ),
    );
  }
  final box = Hive.box('data');

  @override
  void initState() {
    super.initState();
    final containsKey = pin.containsKey('pin');
    containsKey ? confirmPin() : createPin();

    final values = box.values;
    // box.clear();
    print(values);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // extendBody: true,
      // extendBodyBehindAppBar: true,
      bottomNavigationBar: ConvexAppBar(
          cornerRadius: 16,
          height: MediaQuery.of(context).size.height * 0.07,
          activeColor: const Color(0xFF0091FF),
          color: Colors.grey,
          backgroundColor: Colors.white,
          style: TabStyle.fixedCircle,
          items: const [
            TabItem(icon: Icons.home_filled, title: "Home"),
            TabItem(icon: FontAwesomeIcons.globe, title: "Website"),
            TabItem(icon: Icons.copy_rounded),
            TabItem(icon: Icons.error, title: "About us"),
            TabItem(icon: Icons.menu, title: "More")
          ],
          onTap: (int i) async {
            if (i == 1) {
              var uri = Uri.parse('https://www.sherazihealthinnovations.org/');
              await launchUrl(uri);
            } else {
              setState(() {
                ind = i;
              });
            }
          }),
      body: PageStorage(bucket: bucket, child: screens[ind]),
    );
  }
}
