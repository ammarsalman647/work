
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../SleepTime/time.dart';

class Drink extends StatefulWidget {
  const Drink({super.key});

  @override
  State<Drink> createState() => _DrinkState();
}

class _DrinkState extends State<Drink> {

  final box = Hive.box('data');

  String minhour() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return "$hour:$min";
  }

  String DateTym() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return date.month < 10
        ? date.day < 10
            ? "${date.year}-0${date.month}-0${date.day} $hour:$min:00"
            : "${date.year}-0${date.month}-${date.day} $hour:$min:00"
        : date.day < 10
            ? "${date.year}-${date.month}-0${date.day} $hour:$min:00"
            : "${date.year}-${date.month}-${date.day} $hour:$min:00";
  }

  String drinkvolume = "0";
  TextEditingController drinkcontroller = TextEditingController();

  String drinkoption = "Water";

  String notes = "";
  TextEditingController notescontroller = TextEditingController();

  bool pro = false;
  TimeOfDay time = TimeOfDay.now();
  DateTime date = DateTime.now();

  var volumes = [
    {
      'svg' : 'assets/svg/cup.svg',
      'volume': '150'
    },
    {
      'svg' : 'assets/svg/mug.svg',
      'volume': '250'
    },
    {
      'svg' : 'assets/svg/can.svg',
      'volume': '350'
    },
    {
      'svg' : 'assets/svg/bottle.svg',
      'volume': '500'
    },
    {
      'svg' : 'assets/svg/lbottle.svg',
      'volume': '700'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: pro,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Image.asset(
                "assets/images/line.png",
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.fitWidth,
              ),
              Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.045,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: MediaQuery.of(context).size.width * 0.05,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle),
                                child: const Icon(
                                  Icons.arrow_back,
                                  size: 22,
                                  color: Color(0xFF0091FF),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Expanded(
                          flex: 2,
                          child: Center(
                            child: Text(
                              "Add Drink",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: GestureDetector(
                            onTap: () {
                              _selectTime(context);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12)),
                              child: Center(
                                child: Text(
                                  "${formatTimeOfDay(time)}",
                                  style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                      color: Color(0xFF0091FF)),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.02,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.8,
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height * 0.03,
                        right: MediaQuery.of(context).size.width * 0.1,
                        left: MediaQuery.of(context).size.width * 0.1),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          children: [
                            LabelText("Type of Drink"),
                            Row(
                              children: [
                                Option("Water"),
                                SizedBox(
                                  width: 6,
                                ),
                                Option("Juice"),
                                SizedBox(
                                  width: 6,
                                ),
                                Option("Soda"),
                                SizedBox(
                                  width: 6,
                                ),
                                Option("Coffee")
                              ],
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Row(
                              children: [
                                Option("Tea"),
                                SizedBox(
                                  width: 6,
                                ),
                                Option("Milk"),
                                SizedBox(
                                  width: 6,
                                ),
                                Option("Alcohol"),
                                SizedBox(
                                  width: 6,
                                ),
                                Option("Other")
                              ],
                            ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.04,
                            ),
                            LabelText("Drink Volume – Select an option below or enter the approximate drink volume"),
                            GridView.builder(
                                padding: EdgeInsets.zero,
                                shrinkWrap: true,
                              itemCount: volumes.length,
                                gridDelegate:
                            SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 5,
                              crossAxisSpacing: 5,
                              mainAxisSpacing: 5,
                              mainAxisExtent:
                              MediaQuery.of(context).size.height *
                                  0.06,
                            ), itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: (){
                                  setState(() {
                                    drinkcontroller.text = volumes[index]['volume'].toString();
                                    drinkvolume = volumes[index]['volume'].toString();
                                  });
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(color: drinkcontroller.text == volumes[index]['volume']? Colors.blue: Colors.grey),
                                    borderRadius: BorderRadius.circular(10)
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: SvgPicture.asset(
                                    '${volumes[index]['svg']}',
                                        color: drinkcontroller.text == volumes[index]['volume']? Colors.blue: Colors.grey,
                                        semanticsLabel: 'A red up arrow'
                                    ),
                                  ),
                                ),
                              );
                            }),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.01,
                            ),
                            SmallTextBox(),


                            // SizedBox(
                            //   height: MediaQuery.of(context).size.height * 0.04,
                            // ),
                            // TextFormField(
                            //   maxLines: 6,
                            //   decoration: InputDecoration(
                            //     contentPadding: const EdgeInsets.only(
                            //         left: 14, right: 14, top: 12, bottom: 12),
                            //     fillColor: const Color(0xFFF4F4F4),
                            //     filled: true,
                            //     focusedBorder: OutlineInputBorder(
                            //         borderSide: const BorderSide(
                            //           color: Color(0xFFF4F4F4),
                            //         ),
                            //         borderRadius: BorderRadius.circular(12)),
                            //     enabledBorder: UnderlineInputBorder(
                            //         borderSide: const BorderSide(
                            //           color: Color(0xFFF4F4F4),
                            //         ),
                            //         borderRadius: BorderRadius.circular(12)),
                            //     errorBorder: UnderlineInputBorder(
                            //         borderSide: const BorderSide(
                            //           color: Colors.red,
                            //         ),
                            //         borderRadius: BorderRadius.circular(12)),
                            //     focusedErrorBorder: UnderlineInputBorder(
                            //         borderSide: const BorderSide(
                            //           color: Colors.red,
                            //         ),
                            //         borderRadius: BorderRadius.circular(12)),
                            //     hintText: "Other notes...",
                            //     hintStyle: const TextStyle(
                            //         color: Colors.black54,
                            //         fontSize: 15,
                            //         fontWeight: FontWeight.w400),
                            //   ),
                            //   validator: (String? value) {
                            //     return (value!.isEmpty || value == " ")
                            //         ? "Field is essential"
                            //         : null;
                            //   },
                            //   controller: notescontroller,
                            //   onChanged: (value) {
                            //     setState(() {
                            //       notes = value;
                            //     });
                            //   },
                            // ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.02,
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        pro = true;
                                      });
                                      var data = {
                                        "DateTime": DateTime.parse(DateTym()),
                                        "DrinkVol": drinkvolume,
                                        "DrinkOption": drinkoption,
                                      };
                                      final containTime =
                                      box.containsKey(DateTym());
                                      var previousData =
                                      containTime ? box.get(DateTym()) : {};
                                      previousData..addAll(data);

                                      box.put(DateTym(), previousData).then((value) {
                                        setState(() {
                                          pro = false;
                                        });
                                        Navigator.pop(context);
                                      });
                                      // FirebaseFirestore.instance
                                      //     .collection("Users")
                                      //     .doc(FirebaseAuth
                                      //         .instance.currentUser!.uid)
                                      //     .collection("Data")
                                      //     .doc(DateTym())
                                      //     .set({
                                      //   "DateTime": DateTime.parse(DateTym()),
                                      //   "DrinkVol": drinkvolume,
                                      //   "DrinkOption": drinkoption,
                                      // }, SetOptions(merge: true)).then((value) {
                                      //   setState(() {
                                      //     pro = false;
                                      //   });
                                      //   Navigator.pop(context);
                                      // });
                                    },
                                    child: Container(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.05,
                                      decoration: BoxDecoration(
                                          color: Color(0xFF0091FF),
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      child: Center(
                                        child: Text(
                                          "Submit",
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 16,
                                              color: Colors.white),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  LabelText(String tex) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          tex,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),

        ),
        Divider(),
      ],
    );
  }

  SmallTextBox() {
    return TextFormField(
      maxLines: 1,
      keyboardType: TextInputType.numberWithOptions(signed: true, decimal: true),
      decoration: InputDecoration(
        suffixText: "ml",
        suffixStyle:
            TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
        contentPadding:
            const EdgeInsets.only(left: 14, right: 14, top: 12, bottom: 12),
        fillColor: const Color(0xFFF4F4F4),
        filled: true,
        focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: Color(0xFFF4F4F4),
            ),
            borderRadius: BorderRadius.circular(12)),
        enabledBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Color(0xFFF4F4F4),
            ),
            borderRadius: BorderRadius.circular(12)),
        errorBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Colors.red,
            ),
            borderRadius: BorderRadius.circular(12)),
        focusedErrorBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Colors.red,
            ),
            borderRadius: BorderRadius.circular(12)),
        hintText: "0",
        hintStyle: const TextStyle(
            color: Colors.black54, fontSize: 15, fontWeight: FontWeight.w400),
      ),
      validator: (String? value) {
        return (value!.isEmpty || value == " ") ? "Field is essential" : null;
      },
      controller: drinkcontroller,
      onChanged: (value) {
        setState(() {
          drinkvolume = value.toString();
        });
      },
    );
  }

  Option(String tex) {
    return Expanded(
      flex: 1,
      child: InkWell(
        onTap: () {
          setState(() {
            drinkoption = tex;
          });
        },
        child: Container(
          height: MediaQuery.of(context).size.height * 0.05,
          decoration: BoxDecoration(
              color: tex == drinkoption
                  ? Colors.white
                  : Color(0xFF0091FF).withOpacity(0.3),
              border: tex == drinkoption
                  ? Border.all(color: Color(0xFF0091FF), width: 2)
                  : null,
              borderRadius: BorderRadius.circular(8)),
          child: Center(
            child: Text(
              tex,
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  color: tex == drinkoption ? Colors.black : Color(0xFF0091FF)),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }

  _selectTime(BuildContext context) async {
    final TimeOfDay? timeOfDay = await showTimePicker(
      context: context,
      initialTime: time,
      initialEntryMode: TimePickerEntryMode.input,
    );
    // final DateTime? timeOfDay = await DatePicker.showTimePicker(
    //     context, showTitleActions: true,
    //     showSecondsColumn: false,
    //     onChanged: (date) {
    //     }, onConfirm: (date) {
    // }, currentTime: DateTime.now());
    if (timeOfDay != null && timeOfDay != time) {
      setState(() {
        time = timeOfDay;
      });
    }
  }
}
