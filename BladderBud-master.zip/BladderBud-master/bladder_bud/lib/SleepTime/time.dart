import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

class Time extends StatefulWidget {
  final wake;
  const Time({super.key, this.wake});

  @override
  State<Time> createState() => _TimeState();
}

class _TimeState extends State<Time> {
  final box = Hive.box('data');

  String minhour() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return "0:0";
  }

  String DateTym() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return date.month < 10
        ? date.day < 10
            ? "${date.year}-0${date.month}-0${date.day} 00:00:00"
            : "${date.year}-0${date.month}-${date.day} 00:00:00"
        : date.day < 10
            ? "${date.year}-${date.month}-0${date.day} 00:00:00"
            : "${date.year}-${date.month}-${date.day} 00:00:00";
  }

  TimeOfDay time = TimeOfDay.now();
  TimeOfDay time2 = TimeOfDay.now();
  TimeOfDay wakeupTime = TimeOfDay.now();
  TimeOfDay bedTime = TimeOfDay.now();

  bool pro = false;
  DateTime date = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: pro,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Image.asset(
                "assets/images/line.png",
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.fitWidth,
              ),
              Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.045,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: MediaQuery.of(context).size.width * 0.05,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle),
                                child: const Icon(
                                  Icons.arrow_back,
                                  size: 22,
                                  color: Color(0xFF0091FF),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Expanded(
                          flex: 2,
                          child: Center(
                            child: Text(
                              "Wake/Bed Time",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: GestureDetector(
                            onTap: () {
                              // _selectTimeTop(context);
                            },
                            child: SizedBox()
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.02,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.8,
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height * 0.03,
                        right: MediaQuery.of(context).size.width * 0.05,
                        left: MediaQuery.of(context).size.width * 0.05),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          children: [
                            widget.wake
                                ? InkWell(
                                    onTap: () {
                                      _selectTime(context, "wakeup");
                                    },
                                    child: Container(
                                      padding: EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          border: Border.all(
                                              color: Color(0xFF0091FF),
                                              width: 2)),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Wakeup Time",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w500,
                                                    color: Colors.grey),
                                              ),
                                              SizedBox(
                                                height: 8,
                                              ),
                                              Text(
                                                "${formatTimeOfDay(wakeupTime)}",
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ),
                                          SvgPicture.asset(
                                              "assets/images/calendar.svg")
                                        ],
                                      ),
                                    ),
                                  )
                                : SizedBox(),
                            widget.wake
                                ? SizedBox()
                                : InkWell(
                                    onTap: () {
                                      _selectTime(context, "bed");
                                    },
                                    child: Container(
                                      padding: EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          border: Border.all(
                                              color: Color(0xFF0091FF),
                                              width: 2)),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Bed Time",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w500,
                                                    color: Colors.grey),
                                              ),
                                              SizedBox(
                                                height: 8,
                                              ),
                                              Text(
                                                "${formatTimeOfDay(bedTime)}",
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ),
                                          SvgPicture.asset(
                                              "assets/images/calendar.svg")
                                        ],
                                      ),
                                    ),
                                  ),
                          ],
                        ),
                        Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        pro = true;
                                      });

                                      var data = widget.wake? {
                                        "DateTime":
                                        DateTime.parse(DateTym()),
                                        "WakeupTime":
                                        "${formatTimeOfDay(wakeupTime)}",
                                      } :{
                                        "DateTime":
                                        DateTime.parse(DateTym()),
                                        "BedTime":
                                        "${formatTimeOfDay(bedTime)}",
                                      };
                                      final containTime =
                                      box.containsKey(DateTym());
                                      var previousData =
                                      containTime ? box.get(DateTym()) : {};
                                      previousData..addAll(data);

                                      box.put(DateTym(), previousData).then((value) {
                                        setState(() {
                                          pro = false;
                                        });
                                        Navigator.pop(context);
                                      });

                                      // widget.wake
                                      //     ? FirebaseFirestore.instance
                                      //         .collection("Users")
                                      //         .doc(FirebaseAuth
                                      //             .instance.currentUser!.uid)
                                      //         .collection("Data")
                                      //         .doc(DateTym())
                                      //         .set({
                                      //         "DateTime":
                                      //             DateTime.parse(DateTym()),
                                      //         "WakeupTime":
                                      //             "${formatTimeOfDay(wakeupTime)}",
                                      //       }, SetOptions(merge: true)).then(
                                      //             (value) {
                                      //         setState(() {
                                      //           pro = false;
                                      //         });
                                      //         Navigator.pop(context);
                                      //       })
                                      //     : FirebaseFirestore.instance
                                      //         .collection("Users")
                                      //         .doc(FirebaseAuth
                                      //             .instance.currentUser!.uid)
                                      //         .collection("Data")
                                      //         .doc(DateTym())
                                      //         .set({
                                      //         "DateTime":
                                      //             DateTime.parse(DateTym()),
                                      //         "BedTime":
                                      //             "${formatTimeOfDay(bedTime)}",
                                      //       }, SetOptions(merge: true)).then(
                                      //             (value) {
                                      //         setState(() {
                                      //           pro = false;
                                      //         });
                                      //         Navigator.pop(context);
                                      //       });
                                    },
                                    child: Container(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.05,
                                      decoration: BoxDecoration(
                                          color: Color(0xFF0091FF),
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      child: Center(
                                        child: Text(
                                          "Submit",
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 16,
                                              color: Colors.white),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }


  _selectTime(BuildContext context, String lab) async {
    final TimeOfDay? timeOfDay2 = await showTimePicker(
      context: context,
      initialTime: lab == "wakeup" ? wakeupTime : bedTime,
      initialEntryMode: TimePickerEntryMode.input,
    );
    if (timeOfDay2 != null &&
        (timeOfDay2 != wakeupTime || timeOfDay2 != bedTime)) {
      setState(() {
        switch (lab) {
          case "wakeup":
            wakeupTime = timeOfDay2;
            break;
          case "bed":
            bedTime = timeOfDay2;
            break;
          default:
        }
      });
    }
  }

  // _selectTimeTop(BuildContext context) async {
  //   final TimeOfDay? timeOfDay = await showTimePicker(
  //     context: context,
  //     initialTime: time,
  //     initialEntryMode: TimePickerEntryMode.input,
  //   );
  //   if (timeOfDay != null && timeOfDay != time) {
  //     setState(() {
  //       time = timeOfDay;
  //     });
  //   }
  // }
}


String formatTimeOfDay(TimeOfDay tod) {
  final now = new DateTime.now();
  final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
  final format = DateFormat.jm();  //"6:00 AM"
  return format.format(dt);
}