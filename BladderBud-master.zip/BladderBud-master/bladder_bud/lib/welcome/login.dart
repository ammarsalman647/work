// import 'package:bladder_bud/bottombar.dart';
// import 'package:bladder_bud/reminders/models/notification.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_login/flutter_login.dart';
// import 'package:provider/provider.dart';
//
// import '../reminders/models/habit.dart';
//
// class Login extends StatefulWidget {
//   const Login({super.key});
//
//   @override
//   State<Login> createState() => _LoginState();
// }
//
// class _LoginState extends State<Login> {
//   var newUser;
//
//   Duration get loginTime => Duration(milliseconds: 2250);
//
//   Future<String?> _authUser(LoginData data) async {
//     try {
//       await _auth.signInWithEmailAndPassword(
//           email: data.name.toString().trim(),
//           password: data.password.toString().trim());
//       return null;
//     } on FirebaseAuthException catch (e) {
//       return e.message.toString();
//     }
//   }
//
//   Future<String?> _signupUser(SignupData data) async {
//     try {
//       return await _auth
//           .createUserWithEmailAndPassword(
//               email: data.name.toString().toLowerCase().trim(),
//               password: data.password.toString().trim())
//           .then((value) {
//         return FirebaseFirestore.instance
//             .collection('Users')
//             .doc(_auth.currentUser!.uid)
//             .set({"uid": "${_auth.currentUser!.uid}"},
//                 SetOptions(merge: true)).then((value) async {
//           return await _auth.currentUser!.sendEmailVerification().then((value) {
//             loadReminders();
//           }).then((value) {
//             return Future.delayed(loginTime).then((_) {
//               Navigator.push(
//                   context, MaterialPageRoute(builder: (context) => Login()));
//               return "Please Verify Your Email";
//             });
//           });
//         });
//       });
//     } on FirebaseAuthException catch (e) {
//       return e.message;
//     }
//   }
//
//   Future<String> _recoverPassword(String name) {
//     try {
//       return _auth.sendPasswordResetEmail(email: name).then((value) {
//         return Future.delayed(loginTime).then((_) {
//           Navigator.push(
//               context, MaterialPageRoute(builder: (context) => Login()));
//           return "Password Reset Email Sent";
//         });
//       });
//     } on FirebaseAuthException catch (e) {
//       return e.message as Future<String>;
//     }
//   }
//
//   @override
//   void initState() {
//     initializeNotification();
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return FlutterLogin(
//       scrollable: true,
//       theme: LoginTheme(
//         titleStyle: TextStyle(fontWeight: FontWeight.bold),
//         headerMargin: MediaQuery.of(context).size.height * 0.1,
//         footerBottomPadding: 0,
//         pageColorLight: Color(0xFF0091FF),
//         pageColorDark: Color(0xFF00C4FF),
//       ),
//       title: 'Bladder Bud',
//       onLogin: _authUser,
//       onSignup: _signupUser,
//       onSubmitAnimationCompleted: () {
//         Navigator.of(context).pushReplacement(MaterialPageRoute(
//           builder: (context) => Bar(),
//         ));
//       },
//       onRecoverPassword: _recoverPassword,
//     );
//   }
//
//   void loadReminders(){
//     Provider.of<HabitModel>(context,
//         listen: false)
//         .add(
//         name: 'Drink',
//         time: TimeOfDay.now(),
//         daylist: [1, 2, 3, 4, 5, 6, 7]);
//
//     Provider.of<HabitModel>(context,
//         listen: false)
//         .add(
//         name: 'Washroom Visit',
//         time: TimeOfDay.now(),
//         daylist: [1, 2, 3, 4, 5, 6, 7]);
//   }
// }
