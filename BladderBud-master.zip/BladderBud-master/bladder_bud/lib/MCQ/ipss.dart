import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../SleepTime/time.dart';

class ipss extends StatefulWidget {
  const ipss({super.key});

  @override
  State<ipss> createState() => _ipssState();
}

class _ipssState extends State<ipss> {

  final box = Hive.box('data');

  String minhour() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return "$hour:$min";
  }


  String DateTym() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return date.month < 10
        ? date.day < 10
        ? "${date.year}-0${date.month}-0${date.day} $hour:$min:00"
        : "${date.year}-0${date.month}-${date.day} $hour:$min:00"
        : date.day < 10
        ? "${date.year}-${date.month}-0${date.day} $hour:$min:00"
        : "${date.year}-${date.month}-${date.day} $hour:$min:00";
  }

  int Q1 = 6, Q2 = 6, Q3 = 6, Q4 = 6, Q5 = 6, Q6 = 6, Q7 = 6;

  bool pro = false;
  TimeOfDay time = TimeOfDay.now();
  DateTime date = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: pro,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Image.asset(
                "assets/images/line.png",
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.fitWidth,
              ),
              Column(
                children: [
                  SizedBox(
                  height: MediaQuery.of(context).size.height * 0.045,
                ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: MediaQuery.of(context).size.width * 0.05,
                        ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle),
                                child: const Icon(
                                  Icons.arrow_back,
                                  size: 22,
                                  color: Color(0xFF0091FF),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Expanded(
                          flex: 2,
                          child: Center(
                            child: Text(
                              "IPSS",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: GestureDetector(
                            onTap: () {
                              _selectTime(context);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12)),
                              child: Center(
                                child: Text(
                                  "${formatTimeOfDay(time)}",
                                  style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                      color: Color(0xFF0091FF)),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                  height: MediaQuery.of(context).size.height * 0.02,
                ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height * 0.03,
                        right: MediaQuery.of(context).size.width * 0.1,
                        left: MediaQuery.of(context).size.width * 0.1),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                    child: Column(
                      children: [
                        //1
                        Column(
                          children: [
                            Text(
                              "Over the past month, how often have you had a sensation of not emptying your bladder completely after you finished urinating?",
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                            Divider(),
                            RadioListTile(
                              title: Text("Not at all"),
                              value: 0,
                              groupValue: Q1,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q1 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than 1 time in 5"),
                              value: 1,
                              groupValue: Q1,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q1 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than half the time"),
                              value: 2,
                              groupValue: Q1,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q1 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("About half the time"),
                              value: 3,
                              groupValue: Q1,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q1 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("More than half the time"),
                              value: 4,
                              groupValue: Q1,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q1 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Almost always"),
                              value: 5,
                              groupValue: Q1,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q1 = value!;
                                });
                              }),
                            ),
                            SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        ),

                        //2
                        Column(
                          children: [
                            Text(
                              "Over the past month, how often have you had to urinate again less than 2 hours after you finished urinating?",
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                            Divider(),
                            RadioListTile(
                              title: Text("Not at all"),
                              value: 0,
                              groupValue: Q2,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q2 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than 1 time in 5"),
                              value: 1,
                              groupValue: Q2,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q2 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than half the time"),
                              value: 2,
                              groupValue: Q2,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q2 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("About half the time"),
                              value: 3,
                              groupValue: Q2,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q2 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("More than half the time"),
                              value: 4,
                              groupValue: Q2,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q2 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Almost always"),
                              value: 5,
                              groupValue: Q2,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q2 = value!;
                                });
                              }),
                            ),
                            SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        ),

                        //3
                        Column(
                          children: [
                            Text(
                              "Over the past month, how often have you found you stopped and started again several times when you urinated?",
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                            Divider(),
                            RadioListTile(
                              title: Text("Not at all"),
                              value: 0,
                              groupValue: Q3,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q3 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than 1 time in 5"),
                              value: 1,
                              groupValue: Q3,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q3 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than half the time"),
                              value: 2,
                              groupValue: Q3,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q3 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("About half the time"),
                              value: 3,
                              groupValue: Q3,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q3 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("More than half the time"),
                              value: 4,
                              groupValue: Q3,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q3 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Almost always"),
                              value: 5,
                              groupValue: Q3,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q3 = value!;
                                });
                              }),
                            ),
                            SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        ),

                        //4
                        Column(
                          children: [
                            Text(
                              "Over the past month, how often have you found it difficult to postpone urination?",
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                            Divider(),
                            RadioListTile(
                              title: Text("Not at all"),
                              value: 0,
                              groupValue: Q4,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q4 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than 1 time in 5"),
                              value: 1,
                              groupValue: Q4,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q4 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than half the time"),
                              value: 2,
                              groupValue: Q4,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q4 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("About half the time"),
                              value: 3,
                              groupValue: Q4,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q4 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("More than half the time"),
                              value: 4,
                              groupValue: Q4,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q4 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Almost always"),
                              value: 5,
                              groupValue: Q4,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q4 = value!;
                                });
                              }),
                            ),
                            SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        ),

                        //5
                        Column(
                          children: [
                            Text(
                              "Over the past month, how often have you had a weak urinary stream?",
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                            Divider(),
                            RadioListTile(
                              title: Text("Not at all"),
                              value: 0,
                              groupValue: Q5,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q5 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than 1 time in 5"),
                              value: 1,
                              groupValue: Q5,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q5 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than half the time"),
                              value: 2,
                              groupValue: Q5,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q5 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("About half the time"),
                              value: 3,
                              groupValue: Q5,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q5 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("More than half the time"),
                              value: 4,
                              groupValue: Q5,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q5 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Almost always"),
                              value: 5,
                              groupValue: Q5,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q5 = value!;
                                });
                              }),
                            ),
                            SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        ),

                        //6
                        Column(
                          children: [
                            Text(
                              "Over the past month, how often have you had to push or strain to begin urination?",
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                            Divider(),
                            RadioListTile(
                              title: Text("Not at all"),
                              value: 0,
                              groupValue: Q6,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q6 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than 1 time in 5"),
                              value: 1,
                              groupValue: Q6,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q6 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Less than half the time"),
                              value: 2,
                              groupValue: Q6,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q6 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("About half the time"),
                              value: 3,
                              groupValue: Q6,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q6 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("More than half the time"),
                              value: 4,
                              groupValue: Q6,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q6 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("Almost always"),
                              value: 5,
                              groupValue: Q6,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q6 = value!;
                                });
                              }),
                            ),
                            SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.04,
                            ),
                          ],
                        ),

                        //7
                        Column(
                          children: [
                            Text(
                              "Over the past month, how many times did you typically get up to urinate from time you went to bed at night until the time you got up in the morning?",
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                            Divider(),
                            RadioListTile(
                              title: Text("None"),
                              value: 0,
                              groupValue: Q7,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q7 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("1 time"),
                              value: 1,
                              groupValue: Q7,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q7 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("2 times"),
                              value: 2,
                              groupValue: Q7,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q7 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("3 times"),
                              value: 3,
                              groupValue: Q7,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q7 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("4 times"),
                              value: 4,
                              groupValue: Q7,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q7 = value!;
                                });
                              }),
                            ),
                            RadioListTile(
                              title: Text("5 or more times"),
                              value: 5,
                              groupValue: Q7,
                              dense: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 0),
                              onChanged: ((value) {
                                setState(() {
                                  Q7 = value!;
                                });
                              }),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.02,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 1,
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    pro = true;
                                  });
                                  if (Q1 != 6 &&
                                      Q2 != 6 &&
                                      Q3 != 6 &&
                                      Q4 != 6 &&
                                      Q5 != 6 &&
                                      Q6 != 6 &&
                                      Q7 != 6) {
                                    int Q = Q1 + Q2 + Q3 + Q4 + Q5 + Q6 + Q7;

                                    var data = {
                                      "DateTime": DateTime.parse(DateTym()),
                                      "ipss": Q,
                                    };
                                    final containTime =
                                    box.containsKey(DateTym());
                                    var previousData =
                                    containTime ? box.get(DateTym()) : {};
                                    previousData..addAll(data);

                                    box.put(DateTym(), previousData).then((value) {
                                      setState(() {
                                        pro = false;
                                      });
                                      Navigator.pop(context);
                                    });
                                    // FirebaseFirestore.instance
                                    //     .collection("Users")
                                    //     .doc(FirebaseAuth
                                    //         .instance.currentUser!.uid)
                                    //     .collection("Data")
                                    //     .doc(DateTym())
                                    //     .set({
                                    //   "DateTime": DateTime.parse(DateTym()),
                                    //   "ipss": Q,
                                    // }, SetOptions(merge: true)).then((value) {
                                    //   setState(() {
                                    //     pro = false;
                                    //   });
                                    //   Navigator.pop(context);
                                    // });
                                  } else {
                                    setState(() {
                                      pro = false;
                                    });
                                    Fluttertoast.showToast(
                                        msg: "Plz Attempt all Questions",
                                        toastLength: Toast.LENGTH_LONG,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 1,
                                        backgroundColor: Colors.black,
                                        textColor: Colors.white,
                                        fontSize: 14.0);
                                  }
                                },
                                child: Container(
                                  height: MediaQuery.of(context).size.height *
                                      0.05,
                                  decoration: BoxDecoration(
                                      color: Color(0xFF0091FF),
                                      borderRadius: BorderRadius.circular(8)),
                                  child: Center(
                                    child: Text(
                                      "Submit",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                          color: Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.04,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  _selectTime(BuildContext context) async {
    final TimeOfDay? timeOfDay = await showTimePicker(
      context: context,
      initialTime: time,
      initialEntryMode: TimePickerEntryMode.input,
    );
    // final DateTime? timeOfDay = await DatePicker.showTimePicker(
    //     context, showTitleActions: true,
    //     showSecondsColumn: false,
    //     onChanged: (date) {
    //     }, onConfirm: (date) {
    // }, currentTime: DateTime.now());
    if (timeOfDay != null && timeOfDay != time) {
      setState(() {
        time = timeOfDay;
      });
    }
  }
}
