import 'package:bladder_bud/reminders/models/habit.dart';
import 'package:bladder_bud/reminders/pages/home/components/habit_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'modal/add.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  void initState() {
    super.initState();
    // initializeNotification();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Theme.of(context).primaryColor,
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.only(top: 30, right: 30, left: 30),
          child: Column(
            children: <Widget>[
              _header(context),
              Expanded(child: HabitList()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Expanded(
            flex: 1,
            child: RawMaterialButton(
              fillColor: Colors.white,
              shape: new CircleBorder(),
              constraints: BoxConstraints.expand(width: 45, height: 45),
              onPressed: () {
                Navigator.pop(context);
              },
              child: Icon(
                Icons.arrow_back,
                size: 25.0,
                color: Theme.of(context).primaryColor,
              ),
            )),
        Expanded(
          flex: 2,
          child: Center(
            child: Text(
              'Reminder',
              textAlign: TextAlign.left,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: Colors.white),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: RawMaterialButton(
            fillColor: Colors.white,
            shape: new CircleBorder(),
            constraints: BoxConstraints.expand(width: 45, height: 45),
            onPressed: () {
              print('pressed');
              modalAddHabit(context).then(
                (value) {
                  if (value.isEmpty) return;
                  String name = value['name'];
                  TimeOfDay time = TimeOfDay.now();
                  List<int> daylist = [];
                  if (value['isReminderActive']) {
                    time = value['time'];
                    daylist = value['daylist'];
                  }
                  if (name.isNotEmpty && name != '') {
                    Provider.of<HabitModel>(context, listen: false)
                        .add(name: name, time: time, daylist: daylist);
                  }
                },
              );
            },
            child: Icon(
              Icons.add,
              size: 25.0,
              color: Theme.of(context).primaryColor,
            ),
          ),
        )
      ]),
    );
  }
}
