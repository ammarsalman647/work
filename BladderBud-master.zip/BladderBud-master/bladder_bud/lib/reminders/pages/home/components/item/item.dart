// ignore_for_file: unnecessary_null_comparison

import 'package:flutter/material.dart';

import '../../../../constants/app.dart';
import '../../../detail/modal/delete.dart';
import 'date.dart';

const TextStyle title =
    TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.blue);

class HabitItem extends StatefulWidget {
  HabitItem({
    required this.key,
    required this.id,
    required this.name,
    required this.time,
    required this.dayList,
    required this.data,
    required this.toggleDate,
    required this.onTap,
    this.item,
  });

  final Key key;
  final int id;
  final String name;
  final TimeOfDay time;
  final List<int> dayList;
  final List data;
  final Function(DateTime) toggleDate;
  final Function() onTap;
  final item;

  _HabitItemState createState() => _HabitItemState();
}

class _HabitItemState extends State<HabitItem> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Wrap(children: [
        Container(
          padding: EdgeInsets.all(18),
          margin: EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            color: Colors.grey.withOpacity(0.2),
            borderRadius: BorderRadius.all(
              Radius.circular(10),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _header(),
              _checklist(),
            ],
          ),
        )
      ]),
    );
  }

  Widget _header() {
    String? day;
    if (widget.time != null) {
      List dayString = widget.dayList.map((e) => dayShortName[e - 1]).toList();
      day = dayString.length == 7 ? 'Everyday' : dayString.join(', ');
    }
    return Padding(
      padding: EdgeInsets.only(bottom: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (widget.time != null)
                Row(
                  children: [
                    Icon(
                      Icons.alarm,
                      size: 15,
                      color: Colors.black,
                    ),
                    SizedBox(width: 5),
                    Text(
                      widget.time.format(context),
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(width: 5),
                    Icon(
                      Icons.replay,
                      size: 15,
                      color: Colors.black,
                    ),
                    SizedBox(width: 5),
                    Text(
                      day!,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              if (widget.time != null) SizedBox(height: 10),
              Text(
                widget.name,
                style: title,
              )
            ],
          ),
          InkWell(
            onTap: (){
              // print(widget.dayList);
              modalDeleteHabit(context, widget.item.name, widget.item);
            },
              child: Icon(Icons.delete, color: Colors.red,))
        ],
      ),
    );
  }

  Widget _checklist() {
    final List<HabitDate> dateList = [];
    final DateTime currentDate = new DateTime.now();

    for (var i = 6; i >= 0; i--) {
      DateTime date = currentDate.subtract(Duration(days: i));
      String dateString = date.toString().substring(0, 10);
      dateList.add(
        HabitDate(
          date: date,
          isChecked: widget.dayList.contains(i),
          onChange: () => widget.toggleDate(date),
          dayList: widget.dayList,
        ),
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: dateList,
    );
  }
}
