import 'package:bladder_bud/reminders/models/habit.dart';
import 'package:bladder_bud/reminders/pages/home/components/empty_tasks.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../reminder_main.dart';
import 'item/item.dart';

class HabitList extends StatefulWidget {
  HabitList({Key? key}) : super(key: key);

  @override
  _HabitListState createState() => _HabitListState();
}

class _HabitListState extends State<HabitList> {

  @override
  Widget build(BuildContext context) {
    return Consumer<HabitModel>(
      builder: (context, data, child) {
        List<HabitItem> items = [];

        for (var item in data.habits!) {
          item.name == val?
          items.add(HabitItem(
            key: ValueKey(item.id.toString()),
            id: item.id,
            name: item.name,
            time: item.time!,
            dayList: item.daylist!,
            data: item.data!,
            item: item,
            toggleDate: (date) {
              Feedback.forTap(context);
              data.toggleDate(item, date);
            },
            onTap: () {
              // Feedback.forTap(context);
              // modalEditHabit(context, item).then(
              //       (value)  {
              //         print(item);
              //     Provider.of<HabitModel>(context, listen: true).update(item);
              //   },
              // );
            },
          )) : null;
        }
        if (items.length == 0) {
          return EmptyTask();
        }

        return ReorderableListView(
          onReorder: data.reorderHabit,
          children: items,
        );
      },
    );
  }
}
