import 'package:bladder_bud/reminders/pages/home/reminder_main.dart';
import 'package:flutter/material.dart';

class EmptyTask extends StatelessWidget {
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'You have no $val reminder, set your reminder now!',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
