// ignore_for_file: unnecessary_null_comparison

import 'package:flutter/material.dart';

class HabitDate extends StatelessWidget {
  HabitDate(
      {required this.date, this.isChecked = false, required this.onChange, this.dayList});

  final DateTime date;
  final bool isChecked;
  final dayList;
  final Function onChange;

  @override
  Widget build(BuildContext context) {
    final List dayName = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final int weekday = date.weekday - 1;
    final BoxDecoration active = BoxDecoration(
      color: Colors.blue,
      shape: BoxShape.circle,
    );
    final BoxDecoration inActive =
        BoxDecoration(color: Colors.white, shape: BoxShape.circle);

    return GestureDetector(
      onTap: () => {print(isChecked)},
      child: Container(
        child: Column(
          children: [
            Text(
              dayName[weekday],
              style: TextStyle(
                fontSize: 14,
                color: Colors.black,
              ),
            ),
            Container(
              width: 39,
              height: 40,
              margin: EdgeInsets.only(top: 5),
              decoration: dayList.contains(date.weekday) ? active : inActive,
              child: Center(
                child: Text(
                  date.day.toString(),
                  style: TextStyle(
                    fontSize: 15,
                    color: dayList.contains(date.weekday)? Colors.white: Colors.black,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
