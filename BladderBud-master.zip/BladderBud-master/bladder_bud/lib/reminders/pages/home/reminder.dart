import 'package:bladder_bud/reminders/models/habit.dart';
import 'package:bladder_bud/reminders/models/notification.dart';
import 'package:bladder_bud/reminders/pages/home/components/habit_list.dart';
import 'package:bladder_bud/reminders/pages/home/reminder_main.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'modal/add.dart';

class Reminder extends StatefulWidget {
  const Reminder({super.key});

  @override
  State<Reminder> createState() => _ReminderState();
}

class _ReminderState extends State<Reminder> {

  void initState() {
    super.initState();
    print(val);
    initializeNotification();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Image.asset(
              "assets/images/line.png",
              width: MediaQuery.of(context).size.width,
              fit: BoxFit.fitWidth,
            ),
            Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.045,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: MediaQuery.of(context).size.width * 0.05,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                  color: Colors.white, shape: BoxShape.circle),
                              child: const Icon(
                                Icons.arrow_back,
                                size: 22,
                                color: Color(0xFF0091FF),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const Expanded(
                        flex: 2,
                        child: Center(
                          child: Text(
                            "Reminders",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Colors.white),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: InkWell(
                            onTap: () {
                              modalAddHabit(context).then(
                                (value) {
                                  if (value.isEmpty) return;
                                  // String name = value['name'];
                                  TimeOfDay time = TimeOfDay.now();
                                  List<int> daylist = [];
                                  if (value['isReminderActive']) {
                                    print(value['time']);
                                    print(value['daylist']);
                                    time = value['time'];
                                    daylist = value['daylist'];
                                  }

                                    Provider.of<HabitModel>(context,
                                            listen: false)
                                        .add(
                                            name: val,
                                            time: time,
                                            daylist: daylist);

                                },
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                  color: Colors.white, shape: BoxShape.circle),
                              child: const Icon(
                                Icons.add,
                                size: 22,
                                color: Color(0xFF0091FF),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.02,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.8,
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height * 0.03,
                      right: 30,
                      left: 30),
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20))),
                  child: HabitList(),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
