import 'package:flutter/material.dart';

import '../../../../constants/app.dart';
import '../../../../models/habit.dart';
import 'date-item.dart';
import 'header.dart';

class Calendar extends StatefulWidget {
  final Habit habit;
  final Function(DateTime) onToggleDate;

  Calendar({required this.habit, required this.onToggleDate});

  @override
  _CalendarState createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> {
  DateTime date;

  _CalendarState() : this.date = new DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      margin: EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.2),
        borderRadius: BorderRadius.all(
          Radius.circular(10),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CalendarHeader(
            monthShortName[date.month - 1] + " " + date.year.toString(),
            onPrev: () {
              setState(() {
                date = new DateTime(date.year, date.month - 1, 1);
              });
            },
            onNext: () {
              setState(() {
                date = new DateTime(date.year, date.month + 1, 1);
              });
            },
          ),
          SizedBox(height: 10),
          Column(
            children: [
              _dateFirstRow(),
              _dateGrid(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _dateFirstRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Expanded(
          child: Text(
            'Mon',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
        ),
        Expanded(
          child: Text(
            'Tue',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
        ),
        Expanded(
          child: Text(
            'Wed',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
        ),
        Expanded(
          child: Text(
            'Thu',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
        ),
        Expanded(
          child: Text(
            'Fri',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
        ),
        Expanded(
          child: Text(
            'Sat',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
        ),
        Expanded(
          child: Text(
            'Sun',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
        ),
      ],
    );
  }

  Widget _dateGrid() {
    DateTime now = DateTime.now();
    now = DateTime.utc(now.year, now.month, now.day);
    // Get first date of calendar
    DateTime firstDate = DateTime.utc(date.year, date.month, 1);
    int firstWeekInCalendar = DateTime.monday - firstDate.weekday;
    firstDate = firstDate.add(Duration(days: firstWeekInCalendar));

    // Get last date of calendar
    DateTime lastDate = DateTime.utc(date.year, date.month + 1, 0);
    int lastWeekInCalendar = DateTime.sunday - lastDate.weekday;
    lastDate = lastDate.add(Duration(days: lastWeekInCalendar));

    // Generate widget
    List<Row> columnLists = [];
    DateTime current = firstDate;
    int row = 0;
    int column = -1;
    while (current.compareTo(lastDate) <= 0) {
      if (row % 7 == 0) {
        // Create row
        columnLists.add(Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [],
        ));
        column++;
      }

      // Add dateItem Widget
      var dateWidget = DateItem(
        date: current,
        isSecondary: date.month != current.month,
        active:
            widget.habit.data!.indexOf(current.toString().substring(0, 10)) !=
                -1,
        onPressed: (dateClick) {
          // if (date.month != dateClick.month) {
          //   setState(() {
          //     date = new DateTime(dateClick.year, dateClick.month, 1);
          //   });
          // } else {
          //   setState(() {
          //     widget.onToggleDate(dateClick);
          //   });
          // }
        },
        isDisabled: now.compareTo(current) < 0,
      );
      columnLists[column].children.add(dateWidget);

      // Increase current
      current = current.add(Duration(days: 1));
      row++;
    }

    return Column(
      children: columnLists,
    );
  }
}
