import 'package:bladder_bud/reminders/models/habit.dart';
import 'package:bladder_bud/reminders/pages/detail/modal/edit.dart';
import 'package:flutter/material.dart';

class Header extends StatelessWidget {
  Header(this.habit, {required this.onChange});

  final Habit habit;
  final Function(Habit) onChange;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          padding: EdgeInsets.all(0),
          constraints: BoxConstraints(),
          color: Theme.of(context).primaryColor,
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        SizedBox(
          width: 20,
        ),
        Expanded(
          child: Text(
            habit.name,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,

            ),
          ),
        ),
        IconButton(
          padding: EdgeInsets.all(0),
          constraints: BoxConstraints(),
          color: Theme.of(context).primaryColor,
          icon: Icon(Icons.edit),
          onPressed: () {
            modalEditHabit(context, habit).then(
              (value) => {onChange(habit)},
            );
          },
        ),
      ],
    );
  }
}
