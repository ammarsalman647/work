import 'package:bladder_bud/reminders/models/habit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_native_timezone/flutter_native_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

class ReceivedNotification {
  ReceivedNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.payload,
  });

  final int id;
  final String title;
  final String body;
  final String payload;
}

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future initializeNotification() async {
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/launcher_icon');

  final DarwinInitializationSettings initializationSettingsDarwin =
  DarwinInitializationSettings(
    requestAlertPermission: true,
    requestBadgePermission: true,
    requestSoundPermission: true,
  );


  /// Note: permissions aren't requested here just to demonstrate that can be
  /// done later
  final InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,iOS:initializationSettingsDarwin
  );
  await flutterLocalNotificationsPlugin.initialize(initializationSettings,
  //     onSelectNotification: (String payload) async {
  //   if (payload != null) {
  //     if (payload.startsWith('habit-')) {
  //       int habitID = int.parse(payload.substring(6));
  //       Habit habit = await habitAdapter.getById(habitID);
  //       Navigator.pushNamed(
  //         context,
  //         '/detail',
  //         arguments: habit,
  //       );
  //     }
  //   }
  // }
  );

  final String currentTimeZone = await FlutterNativeTimezone.getLocalTimezone();
  tz.initializeTimeZones();
  tz.setLocalLocation(tz.getLocation(currentTimeZone));
}

class NotificationModel {

  static const AndroidNotificationDetails androidPlatformChannelSpecifics =
      AndroidNotificationDetails(
          'habit-notif', 'Reminder',
          importance: Importance.max,
          priority: Priority.high,
          ticker: 'ticker',
          color: Colors.blue);

 static const String darwinNotificationCategoryPlain = 'plainCategory';

 static const String darwinNotificationCategoryText = 'textCategory';

 static const DarwinNotificationDetails darwinNotificationDetails =
  DarwinNotificationDetails(
    categoryIdentifier: darwinNotificationCategoryText,
  );

 static const DarwinNotificationDetails iosNotificationDetails =
  DarwinNotificationDetails(
    categoryIdentifier: darwinNotificationCategoryPlain,
    threadIdentifier:  'habit-notif',
  );


  static const NotificationDetails platformChannelSpecifics =
      NotificationDetails(android: androidPlatformChannelSpecifics, iOS: darwinNotificationDetails);

  static rescheduleNotification(Habit habit) async {
    int notifId = (habit.id * 7) - 7;
    // Cancel all schedule
    for (var i = 0; i < 7; i++) {
      await flutterLocalNotificationsPlugin.cancel(notifId + i);
    }

    if (habit.time == null || habit.daylist!.length == 0) return;

    DateTime now = DateTime.now();
    tz.TZDateTime schedule = tz.TZDateTime.local(
      now.year,
      now.month,
      now.day,
      habit.time!.hour,
      habit.time!.minute,
    );

    // Re-schedule
    for (var item in habit.daylist!) {
      tz.TZDateTime newSchedule =
          schedule.add(new Duration(days: item - now.weekday));
      if (newSchedule.isBefore(DateTime.now())) {
        newSchedule = newSchedule.add(new Duration(days: 7));
      }
      await flutterLocalNotificationsPlugin.zonedSchedule(
          notifId + (item - 1),
          "${habit.name}",
          habit.name == 'Washroom Visit'? 'Reminder to Visit Washroom' : 'Reminder to drink',
          newSchedule,
          platformChannelSpecifics,
          androidAllowWhileIdle: true,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
          payload: 'habit-${habit.id}');
    }
  }

  static removeNotification(Habit habit) async {
    int notifId = (habit.id * 7) - 7;
    // Cancel all schedule
    for (var i = 0; i < 7; i++) {
      await flutterLocalNotificationsPlugin.cancel(notifId + i);
    }
  }
}
