import 'package:bladder_bud/reminders/pages/detail/index.dart';
import 'package:bladder_bud/reminders/pages/home/reminder.dart';
import 'package:flutter/material.dart';

class Routes {
  Routes._();

  //static variables
  // static const String getStarted = '/getStarted';
  static const String home = '/Reminder';
  static const String detail = '/detail';

  static final routes = <String, WidgetBuilder>{
    // getStarted: (BuildContext context) => GetStarted(),
    home: (BuildContext context) => Reminder(),
    detail: (BuildContext context) => Detail(),
  };
}
