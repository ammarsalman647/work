// ignore_for_file: deprecated_member_use

import 'package:bladder_bud/reminders/constants/font_family.dart';
import 'package:flutter/material.dart';

final ThemeData themeData = new ThemeData(
  fontFamily: FontFamily.productSans,
  // brightness: Brightness.dark,
  primaryColor:  Color(0xFF0091FF),
  // primaryColorBrightness: Brightness.dark,
  // accentColorBrightness: Brightness.dark,
  backgroundColor:  Color(0xFF0091FF),
  canvasColor: Colors.transparent,
  textTheme: TextTheme(
    bodyText1: TextStyle(color: Colors.white),
    bodyText2: TextStyle(color: Colors.white, fontSize: 17),
  ),
  iconTheme: IconThemeData(color: Colors.white), colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Colors.blueAccent),
);
