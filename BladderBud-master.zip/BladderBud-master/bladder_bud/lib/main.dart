import 'dart:io';

import 'package:bladder_bud/bottombar.dart';
import 'package:bladder_bud/reminders/models/habit.dart';
import 'package:bladder_bud/reminders/routes.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'reminders/models/notification.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('pin');
  await Hive.openBox('data');

  runApp(ChangeNotifierProvider(
    create: (BuildContext context) => habitAdapter,
    child: const MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  @override
  void initState() {
    super.initState();

  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        routes: Routes.routes,
        debugShowCheckedModeBanner: false,
        home: Bar());
  }
}
