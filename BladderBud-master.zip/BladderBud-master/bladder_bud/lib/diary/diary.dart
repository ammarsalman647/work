
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:syncfusion_flutter_datagrid_export/export.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' hide Column, Row, Stack;

import 'helper/save_file_mobile.dart'
    if (dart.library.html) 'helper/save_file_web.dart' as helper;

List<Employee> employees = <Employee>[];

class Diary extends StatefulWidget {
  const Diary({super.key});

  @override
  State<Diary> createState() => _DiaryState();
}

class _DiaryState extends State<Diary> {
  final box = Hive.box('data');

  var length = Hive.box('data').values;

  EmployeeDataSource employeeDataSource =
      EmployeeDataSource(employeeData: employees);

  String returnDateTime(DateTime TimeStamp) {
    String resultString = '';
    var format = DateFormat('MM/dd hh:mm a');
    resultString = format.format(TimeStamp);
    return resultString;
  }

  bool pro = true;

  Future<void> getData() async {

    var data = box.values;

    data.forEach((element) {
      bool check(String chk) {
        bool ck = false;
        try {
          element.containskey(chk);
        } catch (e) {
          setState(() {
            ck = true;
          });
        }
        return !element.containsKey(chk);
      };
      employees.add(Employee(
          returnDateTime(element["DateTime"]),
          check("WakeupTime") ? "" : "${element["WakeupTime"].toString()}",
          check("BedTime") ? "" : "${element["BedTime"].toString()}",
          check("PeeVolume") ? "" : element["PeeVolume"].toString(),
          check('UrineColor') ? "" : element['UrineColor'].toString(),

          check("LeakOption") ? "" : "${element["LeakOption"].toString()}",
          check("StrongUrge")
              ? ""
              : element["StrongUrge"].toString(),
          check("LeakActivity") ? "" : element["LeakActivity"].toString(),
          check("PooType")
              ? ""
              : "${element["Poo"].toString()} T-${element["PooType"].toString()}",
          check("DrinkVol")
              ? ""
              : "${element["DrinkVol"].toString()} ${element["DrinkOption"].toString()}",
          check("Pad")
              ? ""
              : "${element["Pad"].toString()} ${element["UrinePad"].toString()}",
          check('LeakCloth') ? "" : "${element['LeakCloth']}",
          check("ipss") ? "" : element["ipss"].toString(),
          check("DateTime") ? "" : element["DateTime"].toString()));

    });
    print(employees.toString());

    employeeDataSource = await EmployeeDataSource(employeeData: employees);
    setState(() {
      pro = false;
    });
  }

  @override
  void initState() {
    print(length.length);
    getData();
    super.initState();
  }

  @override
  void dispose() {
    employees.clear();
    super.dispose();
  }

  final GlobalKey<SfDataGridState> _key = GlobalKey<SfDataGridState>();

  Future<void> _exportDataGridToExcel() async {
    final Workbook workbook = _key.currentState!.exportToExcelWorkbook(
        cellExport: (DataGridCellExcelExportDetails details) {
      if (details.columnName == 'peeC' &&
          details.cellValue != 'peeC' &&
          details.cellValue != '') {
        details.excelRange.cellStyle.backColor =
            '${Color(int.parse(details.cellValue.toString())).value.toRadixString(16).padLeft(8, '0')}';
      }
      if (details.columnName == 'peeC' &&
          details.cellValue != 'peeC' &&
          details.cellValue != '') {
        details.excelRange.value = '';
      }
    });

    final List<int> bytes = workbook.saveAsStream();
    workbook.dispose();

    await helper.saveAndLaunchFile(bytes, 'bladderbud.xlsx');
  }

  Future<void> _exportDataGridToPdf() async {
    final PdfDocument document = _key.currentState!.exportToPdfDocument(
        cellExport: (DataGridCellPdfExportDetails details) {
          if (details.columnName == 'peeC' &&
              details.cellValue != 'peeC' &&
              details.cellValue != '') {
            details.pdfCell.style.backgroundBrush = PdfSolidBrush(PdfColor(
                Color(int.parse(details.cellValue.toString())).red,
                Color(int.parse(details.cellValue.toString())).green,
                Color(int.parse(details.cellValue.toString())).blue));
          }
          if (details.columnName == 'peeC' &&
              details.cellValue != 'peeC' &&
              details.cellValue != '') {
            details.pdfCell.value = '';
          }
        },
        fitAllColumnsInOnePage: true);

    final List<int> bytes = document.saveSync();
    await helper.saveAndLaunchFile(bytes, 'bladderbud.pdf');
    document.dispose();
  }

  void exportDialoge(details) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Leak Activity"),
        content: Text(employees[details.rowColumnIndex.rowIndex - 1].activity),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
            },
            child: Container(
              color: Colors.blue,
              padding: const EdgeInsets.all(14),
              child: const Text(
                "okay",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  deleteAlert(context, details) {
    Alert(
      context: context,
      type: AlertType.warning,
      title: "Delete Record",
      desc: "Are you sure you want to delete this record?",
      closeFunction: () {
        setState(() {
          pro = false;
          Navigator.of(context).maybePop(true);
        });
      },
      buttons: [
        DialogButton(
          child: Text(
            "No",
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
          onPressed: () {
            setState(() {
              pro = false;
              Navigator.pop(context);
            });
          },
          color: Color.fromRGBO(0, 179, 134, 1.0),
        ),
        DialogButton(
          child: Text(
            "Delete",
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
          onPressed: () {
            setState(() {
              pro = true;
            });
            var value = employees[details.rowColumnIndex.rowIndex - 1].id.toString();
            box.delete(value.substring(0, value.length-4)).then((value)
            {
              employees.clear();
              getData();
              Navigator.pop(context);
            });
          },
          gradient: LinearGradient(colors: [
            Color.fromRGBO(116, 116, 191, 1.0),
            Color.fromRGBO(52, 138, 199, 1.0),
          ]),
        )
      ],
    ).show();
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: pro,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Image.asset(
                "assets/images/line.png",
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.fitWidth,
              ),
              Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.045,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: MediaQuery.of(context).size.width * 0.05,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle),
                                child: const Icon(
                                  Icons.arrow_back,
                                  size: 22,
                                  color: Color(0xFF0091FF),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Expanded(
                          flex: 1,
                          child: Center(
                            child: Text(
                              "Diary",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: GestureDetector(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (ctx) => AlertDialog(
                                    title: const Text("Export File Format?"),
                                    actions: <Widget>[
                                      TextButton(
                                        onPressed: () {
                                          _exportDataGridToPdf();
                                          Navigator.of(ctx).pop();
                                        },
                                        child: Container(
                                          color: Colors.blue,
                                          padding: const EdgeInsets.all(14),
                                          child: const Text(
                                            "Pdf",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          _exportDataGridToExcel();
                                          Navigator.of(ctx).pop();
                                        },
                                        child: Container(
                                          color: Colors.green,
                                          padding: const EdgeInsets.all(14),
                                          child: const Text(
                                            "Excel",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle),
                                child: const Icon(
                                  FontAwesomeIcons.share,
                                  size: 22,
                                  color: Color(0xFF0091FF),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.02,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.9,
                    padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height * 0.03,
                      bottom: MediaQuery.of(context).size.height * 0.05,
                      right: MediaQuery.of(context).size.width * 0.02,
                      left: MediaQuery.of(context).size.width * 0.02,
                    ),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                    child: SfDataGrid(
                      key: _key,
                      onCellTap: (details) {
                        details.rowColumnIndex.columnIndex == 5
                            ? employees[details.rowColumnIndex.rowIndex - 1]
                                        .activity !=
                                    ""
                                ? exportDialoge(details)
                                : null
                            : details.rowColumnIndex.columnIndex == 13
                                ? setState(() {
                                    deleteAlert(context, details);
                                  })
                                : null;
                      },
                      source: employeeDataSource,
                      frozenColumnsCount: 1,
                      isScrollbarAlwaysShown: true,
                      horizontalScrollPhysics: AlwaysScrollableScrollPhysics(),
                      verticalScrollPhysics: AlwaysScrollableScrollPhysics(),
                      columnWidthMode: ColumnWidthMode.fill,
                      gridLinesVisibility: GridLinesVisibility.both,
                      headerGridLinesVisibility: GridLinesVisibility.both,
                      columns: <GridColumn>[
                        GridColumn(
                            minimumWidth: 140,
                            columnName: 'datetime',
                            label: Container(
                                padding: EdgeInsets.all(16.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Date Time',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 120,
                            columnName: 'wake',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Wakeup Time',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 120,
                            columnName: 'bed',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Bed Time',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 80,
                            columnName: 'pee',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Pee (ml)',
                                  // overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 100,
                            columnName: 'peeC',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Pee Color',
                                  // overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 100,
                            columnName: 'strongurge',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Strong Urge',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 130,
                            columnName: 'leak',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Leak',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 120,
                            columnName: 'activity',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Activity at time of leak',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 100,
                            columnName: 'poo',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Poo',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 100,
                            columnName: 'drink',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Drink (ml)',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 100,
                            columnName: 'pad',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Pad Change',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 100,
                            columnName: 'leakCloth',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'Leakage to clothing ',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 50,
                            columnName: 'ipss',
                            label: Container(
                                padding: EdgeInsets.all(8.0),
                                alignment: Alignment.center,
                                child: Text(
                                  'IPSS',
                                  style: TextStyle(
                                      color: Color(0xFF0091FF),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14),
                                ))),
                        GridColumn(
                            minimumWidth: 50,
                            columnName: 'id',
                            label: SizedBox()),
                      ],
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Employee {
  /// Creates the employee class with required details.
  Employee(
      this.datetime,
      this.wake,
      this.bed,
      this.pee,
      this.peeColor,
      this.leak,
      this.strongurge,
      this.activity,
      this.poo,
      this.drink,
      this.pad,
      this.leakCloth,
      this.ipss,
      this.id);

  final String datetime,
      wake,
      bed,
      pee,
      peeColor,
      leak,
      strongurge,
      activity,
      poo,
      drink,
      pad,
      leakCloth,
      ipss,
      id;
}


class EmployeeDataSource extends DataGridSource {
  /// Creates the employee data source class with required details.
  EmployeeDataSource({required List<Employee> employeeData}) {
    _employeeData = employeeData
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<String>(columnName: 'datetime', value: e.datetime),
              DataGridCell<String>(columnName: 'wake', value: e.wake),
              DataGridCell<String>(columnName: 'bed', value: e.bed),
              DataGridCell<String>(
                columnName: 'pee',
                value: e.pee,
              ),
              DataGridCell<String>(
                columnName: 'peeC',
                value: e.peeColor,
              ),
              DataGridCell<String>(
                  columnName: 'strongurge', value: e.strongurge),
              DataGridCell<String>(columnName: 'leak', value: e.leak),
              DataGridCell<String>(columnName: 'activity', value: e.activity),
              DataGridCell<String>(columnName: 'poo', value: e.poo),
              DataGridCell<String>(columnName: 'drink', value: e.drink),
              DataGridCell<String>(columnName: 'pad', value: e.pad),
              DataGridCell<String>(columnName: 'leakCloth', value: e.leakCloth),
              DataGridCell<String>(columnName: 'ipss', value: e.ipss),
              DataGridCell<String>(columnName: 'id', value: e.id),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        cells: row.getCells().map<Widget>((e) {
      return Container(
        decoration: BoxDecoration(
            color: e.columnName == "peeC"
                ? e.value != ''
                    ? Color(int.parse(e.value.toString()))
                    : Colors.white
                : Colors.white),
        alignment: Alignment.center,
        padding: EdgeInsets.all(8.0),
        child: e.columnName == 'id'
            ? Icon(
                Icons.delete,
                color: Colors.blue,
                size: 20,
              )
            : Text(
                e.columnName == 'peeC' ? '' : e.value,
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: TextStyle(
                  color: e.columnName == 'wake' || e.columnName == 'bed'
                      ? Colors.purple
                      : e.columnName == "pee" || e.columnName == 'strongurge'
                          ? Color(0xff00008B)
                          : e.columnName == "leak" || e.columnName == 'activity'
                              ? Color(0xff023020)
                              : e.columnName == "poo"
                                  ? Color(0xff800000)
                                  : e.columnName == "drink"
                                      ? Color(0xff228B22)
                                      : e.columnName == 'pad' ||
                                              e.columnName == 'leakCloth'
                                          ? Colors.red
                                          : Colors.black,
                  decoration: e.columnName == "activity"
                      ? e.value == ""
                          ? null
                          : TextDecoration.underline
                      : null,
                ),
              ),
      );
    }).toList());
  }
}

extension HexColor on Color {
  /// String is in the format "aabbcc" or "ffaabbcc" with an optional leading "#".
  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }

  /// Prefixes a hash sign if [leadingHashSign] is set to `true` (default is `true`).
  String toHex({bool leadingHashSign = true}) => '${leadingHashSign ? '#' : ''}'
      '${red.toRadixString(16).padLeft(2, '0')}'
      '${green.toRadixString(16).padLeft(2, '0')}'
      '${blue.toRadixString(16).padLeft(2, '0')}'
      '${alpha.toRadixString(16).padLeft(2, '0')}';
}
