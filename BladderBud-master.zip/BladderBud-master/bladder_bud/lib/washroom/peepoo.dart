import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../SleepTime/time.dart';

class PeePoo extends StatefulWidget {
  const PeePoo({super.key});

  @override
  State<PeePoo> createState() => _PeePooState();
}

class _PeePooState extends State<PeePoo> {

  final box = Hive.box('data');


  String minhour() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return "$hour:$min";
  }

  String DateTym() {
    String hour, min;
    if (time.hour <= 9) {
      hour = "0${time.hour}";
    } else {
      hour = time.hour.toString();
    }
    if (time.minute <= 9) {
      min = "0${time.minute}";
    } else {
      min = time.minute.toString();
    }
    return date.month < 10
        ? date.day < 10
            ? "${date.year}-0${date.month}-0${date.day} $hour:$min:00"
            : "${date.year}-0${date.month}-${date.day} $hour:$min:00"
        : date.day < 10
            ? "${date.year}-${date.month}-0${date.day} $hour:$min:00"
            : "${date.year}-${date.month}-${date.day} $hour:$min:00";
  }

  bool tab = true;

  bool leak = true;
  String leakactivity = "";
  String leakvolume = "";
  String leakoption = "No Leak";
  TextEditingController leakactcontroller = TextEditingController();
  TextEditingController leakvolcontroller = TextEditingController();

  bool pee = true;
  String peevolume = "";
  TextEditingController peevolcontroller = TextEditingController();

  String urgencyoption = "";
  bool strongurge = true;
  String urgency = "";
  TextEditingController urgencycontroller = TextEditingController();

  int coloroption = Colors.white.value;
  String notes = "";
  TextEditingController notescontroller = TextEditingController();

  //Poo
  String poooption = "Small";

  String likeoption = "Liquid";

  String accedentoption = "No";

  int type = 1;

  String poonotes = "";
  TextEditingController poonotescontroller = TextEditingController();

  var leakList = [
    {'name': 'No Leak', 'val': 'leak'},
    {'name': 'Few Drops', 'val': 'leak'},
    {'name': 'Small', 'val': 'leak'},
    {'name': 'Medium', 'val': 'leak'},
    {'name': 'Large', 'val': 'leak'}
  ];

  bool pro = false;
  TimeOfDay time = TimeOfDay.now();
  DateTime date = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: pro,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Image.asset(
                "assets/images/line.png",
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.fitWidth,
              ),
              Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.045,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: MediaQuery.of(context).size.width * 0.05,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle),
                                child: const Icon(
                                  Icons.arrow_back,
                                  size: 22,
                                  color: Color(0xFF0091FF),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Expanded(
                          flex: 2,
                          child: Center(
                            child: Text(
                              "Add Pee & Poo",
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: GestureDetector(
                            onTap: () {
                              _selectTime(context);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12)),
                              child: Center(
                                child: Text(
                                  "${formatTimeOfDay(time)}",
                                  style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                      color: Color(0xFF0091FF)),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.02,
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).size.height * 0.03,
                        right: MediaQuery.of(context).size.width * 0.1,
                        left: MediaQuery.of(context).size.width * 0.1),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                    child: Column(
                      children: [
                        Container(
                          height: MediaQuery.of(context).size.height * 0.06,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                              color: Color(0xFFE2E2E2),
                              borderRadius: BorderRadius.circular(12)),
                          child: Row(
                            children: [
                              Expanded(
                                flex: 1,
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      tab = true;
                                    });
                                  },
                                  child: Container(
                                    decoration: tab
                                        ? BoxDecoration(
                                            color: Color(0xFF0091FF),
                                            borderRadius:
                                                BorderRadius.circular(12))
                                        : null,
                                    child: Center(
                                      child: Text(
                                        "Pee/Leak",
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color: tab
                                                ? Colors.white
                                                : Colors.black),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      tab = false;
                                    });
                                  },
                                  child: Container(
                                    decoration: tab
                                        ? null
                                        : BoxDecoration(
                                            color: Color(0xFF0091FF),
                                            borderRadius:
                                                BorderRadius.circular(12)),
                                    child: Center(
                                      child: Text(
                                        "Poo",
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color: tab
                                                ? Colors.black
                                                : Colors.white),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: tab,
                          child: Column(
                            children: [
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.03,
                              ),
                              LabelText("Pee"),
                              TwoButton(pee, "pee"),
                              SizedBox(
                                height:
                                MediaQuery.of(context).size.height * 0.04,
                              ),
                              LabelText("Volume Peed"),
                              SmallTextBox("pee"),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.04,
                              // ),
                              // LabelText("Urgency"),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.01,
                              // ),
                              // Row(
                              //   children: [
                              //     Option("0", "urgency"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("1", "urgency"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("2", "urgency"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("3", "urgency"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("4", "urgency"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("5", "urgency"),
                              //   ],
                              // ),
                              SizedBox(
                                height:
                                MediaQuery.of(context).size.height * 0.04,
                              ),
                              LabelText("Strong Urge"),
                              TwoButton(strongurge, "urgency"),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.01,
                              // ),
                              // MedTextBox("Other notes...", "urgency"),
                              SizedBox(
                                height:
                                MediaQuery.of(context).size.height * 0.04,
                              ),
                              LabelText("Urine Color"),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  ColorOption(Colors.white, 1, "urine"),
                                  ColorOption(Color(0xFFFDFFE2), 2, "urine"),
                                  ColorOption(Color(0xFFFDF4A9), 3, "urine"),
                                  ColorOption(Color(0xFFFCE971), 4, "urine"),
                                  ColorOption(Color(0xFFF9D400), 5, "urine"),
                                ],
                              ),
                              SizedBox(
                                height: MediaQuery.of(context).size.height * 0.01,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  ColorOption(Color(0xFFEBA104), 6, "urine"),
                                  ColorOption(Color(0xFFDE6F04), 7, "urine"),
                                  ColorOption(Color(0xFFD13C06), 8, "urine"),
                                  ColorOption(Colors.red.shade900, 9, "urine"),
                                  ColorOption(Colors.red.shade600, 10, "urine"),
                                ],
                              ),

                              SizedBox(
                                height:
                                MediaQuery.of(context).size.height * 0.04,
                              ),
                              LabelText("Accidental Leak"),


                              GridView.builder(
                                  shrinkWrap: true,
                                  itemCount: leakList.length,
                                  padding: EdgeInsets.zero,
                                  physics: NeverScrollableScrollPhysics(),
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 4,
                                    crossAxisSpacing: 5,
                                    mainAxisSpacing: 5,
                                    mainAxisExtent:
                                        MediaQuery.of(context).size.height *
                                            0.06,
                                  ),
                                  itemBuilder: (context, index) {
                                    return Option(leakList[index]['name']!, leakList[index]['val']!);
                                  }),
                              // Row(
                              //   children: [
                              //     Option("Few Drops", "leak"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("Small", "leak"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("Medium", "leak"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     Option("Large", "leak"),
                              //   ],
                              // ),
                              SizedBox(
                                height:
                                MediaQuery.of(context).size.height * 0.02,
                              ),
                              LabelText("What were you doing at the time of the leak?"),
                              MedTextBox("eg. Coughing, laughing, sneezing, bending, heavy lifting, running, sleeping, etc", "leak"),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.03,
                              // ),
                              // LabelText("Approximate Volume Leaked"),
                              // SmallTextBox("leak"),

                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.04,
                              // ),
                              // TextFormField(
                              //   maxLines: 6,
                              //   decoration: InputDecoration(
                              //     contentPadding: const EdgeInsets.only(
                              //         left: 14, right: 14, top: 12, bottom: 12),
                              //     fillColor: const Color(0xFFF4F4F4),
                              //     filled: true,
                              //     focusedBorder: OutlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Color(0xFFF4F4F4),
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     enabledBorder: UnderlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Color(0xFFF4F4F4),
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     errorBorder: UnderlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Colors.red,
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     focusedErrorBorder: UnderlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Colors.red,
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     hintText: "Other notes...",
                              //     hintStyle: const TextStyle(
                              //         color: Colors.black54,
                              //         fontSize: 15,
                              //         fontWeight: FontWeight.w400),
                              //   ),
                              //   validator: (String? value) {
                              //     return (value!.isEmpty || value == " ")
                              //         ? "Field is essential"
                              //         : null;
                              //   },
                              //   controller: notescontroller,
                              //   onChanged: (value) {
                              //     setState(() {
                              //       notes = value;
                              //     });
                              //   },
                              // ),
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.02,
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    flex: 1,
                                    child: InkWell(
                                      onTap: () {
                                        setState(() {
                                          tab = false;
                                        });
                                      },
                                      child: Container(
                                        height:
                                            MediaQuery.of(context).size.height *
                                                0.05,
                                        decoration: BoxDecoration(
                                            color: Color(0xFF0091FF),
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                        child: Center(
                                          child: Text(
                                            "Enter Poo",
                                            style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 16,
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Visibility(
                          visible: !tab,
                          child: Column(
                            children: [
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.04,
                              ),
                              PooLabelText("How big was the poo?"),
                              Row(
                                children: [
                                  PooOption("Small", "bigpoo"),
                                  SizedBox(
                                    width: 6,
                                  ),
                                  PooOption("Medium", "bigpoo"),
                                  SizedBox(
                                    width: 6,
                                  ),
                                  PooOption("Large", "bigpoo"),
                                ],
                              ),
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.04,
                              ),
                              // PooLabelText("What was the poo like?"),
                              // Row(
                              //   children: [
                              //     PooOption("Liquid", "poolike"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     PooOption("Soft", "poolike"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     PooOption("Hard", "poolike"),
                              //   ],
                              // ),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.04,
                              // ),
                              PooLabelText("Type of Poo"),
                              // Row(
                              //   children: [
                              //     PooOption("No", "accedent"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     PooOption("Stained Underwear", "accedent"),
                              //   ],
                              // ),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.01,
                              // ),
                              // Row(
                              //   children: [
                              //     PooOption("Small", "accedent"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     PooOption("Medium", "accedent"),
                              //     SizedBox(
                              //       width: 6,
                              //     ),
                              //     PooOption("Large", "accedent"),
                              //   ],
                              // ),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.02,
                              // ),
                              Divider(
                                height: 0,
                              ),

                              Type(context, 1, "Separate hard lumps"),
                              Type(context, 2, "Lumpy and sausage like"),
                              Type(context, 3,
                                  "A sausage shape with cracks in the surface"),
                              Type(context, 4,
                                  "Like a smooth, soft sausage or snake"),
                              Type(context, 5,
                                  "Like a smooth, soft sausage or snake"),
                              Type(context, 6,
                                  "Mushy consistency with ragged edges"),
                              Type(context, 7,
                                  "Liquid consistency with no solid pieces"),
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.01,
                              // ),
                              // TextFormField(
                              //   maxLines: 6,
                              //   decoration: InputDecoration(
                              //     contentPadding: const EdgeInsets.only(
                              //         left: 14, right: 14, top: 12, bottom: 12),
                              //     fillColor: const Color(0xFFF4F4F4),
                              //     filled: true,
                              //     focusedBorder: OutlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Color(0xFFF4F4F4),
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     enabledBorder: UnderlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Color(0xFFF4F4F4),
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     errorBorder: UnderlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Colors.red,
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     focusedErrorBorder: UnderlineInputBorder(
                              //         borderSide: const BorderSide(
                              //           color: Colors.red,
                              //         ),
                              //         borderRadius: BorderRadius.circular(12)),
                              //     hintText: "Other notes...",
                              //     hintStyle: const TextStyle(
                              //         color: Colors.black54,
                              //         fontSize: 15,
                              //         fontWeight: FontWeight.w400),
                              //   ),
                              //   validator: (String? value) {
                              //     return (value!.isEmpty || value == " ")
                              //         ? "Field is essential"
                              //         : null;
                              //   },
                              //   controller: poonotescontroller,
                              //   onChanged: (value) {
                              //     setState(() {
                              //       poonotes = value;
                              //     });
                              //   },
                              // ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.02,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 1,
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    pro = true;
                                  });

                                  var data = {
                                    "DateTime": DateTime.parse(DateTym()),
                                    "Leak": leak,
                                    "LeakActivity": leakactivity,
                                    "LeakOption": leakoption,
                                    "Pee": pee,
                                    "PeeVolume": peevolume,
                                    "StrongUrge": strongurge? 'Yes': 'No',
                                    "UrineColor": coloroption,
                                    "Poo": poooption,
                                    "PooType": type,
                                  };

                                  final containTime =
                                  box.containsKey(DateTym());
                                  var previousData =
                                  containTime ? box.get(DateTym()) : {};
                                  previousData..addAll(data);

                                  box.put(DateTym(), previousData).then((value) {
                                    setState(() {
                                      pro = false;
                                    });
                                    Navigator.pop(context);
                                  });

                                  // FirebaseFirestore.instance
                                  //     .collection("Users")
                                  //     .doc(FirebaseAuth
                                  //         .instance.currentUser!.uid)
                                  //     .collection("Data")
                                  //     .doc(DateTym())
                                  //     .set({
                                  //   "DateTime": DateTime.parse(DateTym()),
                                  //   "Leak": leak,
                                  //   "LeakActivity": leakactivity,
                                  //   "LeakOption": leakoption,
                                  //   "Pee": pee,
                                  //   "PeeVolume": peevolume,
                                  //   "StrongUrge": strongurge,
                                  //   "UrineColor": coloroption,
                                  //   "Poo": poooption,
                                  //   "PooType": type,
                                  // }, SetOptions(merge: true)).then((value) {
                                  //   setState(() {
                                  //     pro = false;
                                  //   });
                                  //   Navigator.pop(context);
                                  // });
                                },
                                child: Container(
                                  height:
                                      MediaQuery.of(context).size.height * 0.05,
                                  decoration: BoxDecoration(
                                      color: Color(0xFF0091FF),
                                      borderRadius: BorderRadius.circular(8)),
                                  child: Center(
                                    child: Text(
                                      "Submit",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                          color: Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.04,
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  LabelText(String tex) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          tex,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        Divider(
        ),
      ],
    );
  }

  TwoButton(bool press, String lab) {
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: InkWell(
            onTap: () {
              setState(() {
                press = true;
                switch (lab) {
                  case "leak":
                    leak = press;
                    break;
                  case "pee":
                    pee = press;
                    break;
                  case "urgency":
                    strongurge = press;
                    break;
                  default:
                }
              });
            },
            child: Container(
              height: MediaQuery.of(context).size.height * 0.05,
              decoration: BoxDecoration(
                  color: press ? Color(0xFF0091FF) : Color(0xFFD3D3D3),
                  borderRadius: BorderRadius.circular(8)),
              child: Center(
                child: Text(
                  "Yes",
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: press ? Colors.white : Colors.black),
                ),
              ),
            ),
          ),
        ),
        SizedBox(
          width: MediaQuery.of(context).size.width * 0.05,
        ),
        Expanded(
          flex: 1,
          child: InkWell(
            onTap: () {
              setState(() {
                press = false;
                switch (lab) {
                  case "leak":
                    leak = press;
                    break;
                  case "pee":
                    pee = press;
                    break;
                  case "urgency":
                    strongurge = press;
                    break;
                  default:
                }
              });
            },
            child: Container(
              height: MediaQuery.of(context).size.height * 0.05,
              decoration: BoxDecoration(
                  color: press ? Color(0xFFD3D3D3) : Color(0xFF0091FF),
                  borderRadius: BorderRadius.circular(8)),
              child: Center(
                child: Text(
                  "No",
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: press ? Colors.black : Colors.white),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  MedTextBox(String tex, String lab) {
    return TextFormField(
      maxLines: 3,
      keyboardType: TextInputType.text,
      decoration: InputDecoration(
        contentPadding:
            const EdgeInsets.only(left: 14, right: 14, top: 12, bottom: 12),
        fillColor: const Color(0xFFF4F4F4),
        filled: true,
        focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: Color(0xFFF4F4F4),
            ),
            borderRadius: BorderRadius.circular(12)),
        enabledBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Color(0xFFF4F4F4),
            ),
            borderRadius: BorderRadius.circular(12)),
        errorBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Colors.red,
            ),
            borderRadius: BorderRadius.circular(12)),
        focusedErrorBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Colors.red,
            ),
            borderRadius: BorderRadius.circular(12)),
        hintText: tex,
        hintStyle: const TextStyle(
            color: Colors.black54, fontSize: 13, fontWeight: FontWeight.w400),
      ),
      validator: (String? value) {
        return (value!.isEmpty || value == " ") ? "Field is essential" : null;
      },
      controller: lab == "leak"
          ? leakactcontroller
          : lab == "urgency"
              ? urgencycontroller
              : null,
      onChanged: (value) {
        setState(() {
          lab == "leak"
              ? leakactivity = value
              : lab == "urgency"
                  ? urgency = value
                  : null;
        });
      },
    );
  }

  SmallTextBox(String lab) {
    return TextFormField(
      maxLines: 1,
      keyboardType: TextInputType.numberWithOptions(signed: true, decimal: true),
      decoration: InputDecoration(
        suffixText: "ml",
        suffixStyle:
            TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
        contentPadding:
            const EdgeInsets.only(left: 14, right: 14, top: 12, bottom: 12),
        fillColor: const Color(0xFFF4F4F4),
        filled: true,
        focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: Color(0xFFF4F4F4),
            ),
            borderRadius: BorderRadius.circular(12)),
        enabledBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Color(0xFFF4F4F4),
            ),
            borderRadius: BorderRadius.circular(12)),
        errorBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Colors.red,
            ),
            borderRadius: BorderRadius.circular(12)),
        focusedErrorBorder: UnderlineInputBorder(
            borderSide: const BorderSide(
              color: Colors.red,
            ),
            borderRadius: BorderRadius.circular(12)),
        hintText: "0",
        hintStyle: const TextStyle(
            color: Colors.black54, fontSize: 15, fontWeight: FontWeight.w400),
      ),
      validator: (String? value) {
        return (value!.isEmpty || value == " ") ? "Field is essential" : null;
      },
      controller: lab == "leak"
          ? leakvolcontroller
          : lab == "pee"
              ? peevolcontroller
              : null,
      onChanged: (value) {
        setState(() {
          lab == "leak"
              ? leakvolume = value
              : lab == "pee"
                  ? peevolume = value
                  : null;
        });
      },
    );
  }

  Option(String tex, String lab) {
    return InkWell(
      onTap: () {
        setState(() {
          switch (lab) {
            case "leak":
              leakoption = tex;
              break;
            case "urgency":
              urgencyoption = tex;
              break;
            default:
          }
        });
      },
      child: Container(
        height: MediaQuery.of(context).size.height * 0.05,
        decoration: BoxDecoration(
            color: lab == "leak"
                ? tex == leakoption
                    ? Colors.white
                    : Color(0xFF0091FF).withOpacity(0.3)
                : lab == "urgency"
                    ? tex == urgencyoption
                        ? Colors.white
                        : Color(0xFF0091FF).withOpacity(0.3)
                    : null,
            border: lab == "leak"
                ? tex == leakoption
                    ? Border.all(color: Color(0xFF0091FF), width: 2)
                    : null
                : lab == "urgency"
                    ? tex == urgencyoption
                        ? Border.all(color: Color(0xFF0091FF), width: 2)
                        : null
                    : null,
            borderRadius: BorderRadius.circular(8)),
        child: Center(
          child: Text(
            tex,
            style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
                color: lab == "leak"
                    ? tex == leakoption
                        ? Colors.black
                        : Color(0xFF0091FF)
                    : lab == "urgency"
                        ? tex == urgencyoption
                            ? Colors.black
                            : Color(0xFF0091FF)
                        : null),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  ColorOption(Color col, int i, String lab) {
    return InkWell(
      onTap: () {
        setState(() {
          switch (lab) {
            case "urine":
              coloroption = col.value;
              break;
            default:
          }
        });
      },
      child: Container(
        height: MediaQuery.of(context).size.height * 0.06,
        width: MediaQuery.of(context).size.width * 0.15,
        decoration: BoxDecoration(
            color: col,
            border: lab == "urine"
                ? col.value == coloroption
                    ? Border.all(color: Color(0xFF0091FF), width: 2)
                    : null
                : null,
            borderRadius: BorderRadius.circular(8)),
        child: col == Colors.white? Center(
          child: Text('Clear'),
        ) : null,
      ),
    );
  }

  Type(BuildContext context, int i, String tex) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: () {
          setState(() {
            type = i;
          });
        },
        child: Row(
          children: [
            PhysicalModel(
              elevation: 5,
              borderRadius: BorderRadius.circular(10),
              color: Color(0xFFF9F9FB),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.15,
                height: MediaQuery.of(context).size.height * 0.08,
                decoration: BoxDecoration(
                  color: Color(0xFFF9F9FB),
                  border: i == type
                      ? Border.all(color: Color(0xFF0091FF), width: 2)
                      : null,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Image.asset(
                  "assets/images/${i}.png",
                  width: MediaQuery.of(context).size.width * 0.2,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 8),
              height: MediaQuery.of(context).size.height * 0.08,
              width: MediaQuery.of(context).size.width * 0.6,
              padding: EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                  border: i == type
                      ? Border.all(color: Color(0xFF0091FF), width: 2)
                      : null,
                  color: i == type ? Colors.white : Color(0xFFEBEBEB),
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          "Type ${i}",
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(
                            height: MediaQuery.of(context).size.height * 0.06,
                            child: VerticalDivider()),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Center(
                      child: Text(
                        tex,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  PooLabelText(String tex) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          tex,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        Divider(),
      ],
    );
  }

  PooOption(String tex, String lab) {
    return Expanded(
      flex: 1,
      child: InkWell(
        onTap: () {
          setState(() {
            switch (lab) {
              case "bigpoo":
                poooption = tex;
                break;
              case "poolike":
                likeoption = tex;
                break;
              case "accedent":
                accedentoption = tex;
                break;
              default:
            }
          });
        },
        child: Container(
          height: MediaQuery.of(context).size.height * 0.05,
          decoration: BoxDecoration(
              color: lab == "bigpoo"
                  ? tex == poooption
                      ? Colors.white
                      : Color(0xFF0091FF).withOpacity(0.3)
                  : lab == "poolike"
                      ? tex == likeoption
                          ? Colors.white
                          : Color(0xFF0091FF).withOpacity(0.3)
                      : lab == "accedent"
                          ? tex == accedentoption
                              ? Colors.white
                              : Color(0xFF0091FF).withOpacity(0.3)
                          : null,
              border: lab == "bigpoo"
                  ? tex == poooption
                      ? Border.all(color: Color(0xFF0091FF), width: 2)
                      : null
                  : lab == "poolike"
                      ? tex == likeoption
                          ? Border.all(color: Color(0xFF0091FF), width: 2)
                          : null
                      : lab == "accedent"
                          ? tex == accedentoption
                              ? Border.all(color: Color(0xFF0091FF), width: 2)
                              : null
                          : null,
              borderRadius: BorderRadius.circular(8)),
          child: Center(
            child: Text(
              tex,
              style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                  color: lab == "bigpoo"
                      ? tex == poooption
                          ? Colors.black
                          : Color(0xFF0091FF)
                      : lab == "poolike"
                          ? tex == likeoption
                              ? Colors.black
                              : Color(0xFF0091FF)
                          : lab == "accedent"
                              ? tex == accedentoption
                                  ? Colors.black
                                  : Color(0xFF0091FF)
                              : null),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }

  _selectTime(BuildContext context) async {
    // final DateTime? timeOfDay = await DatePicker.showTimePicker(
    //     context, showTitleActions: true,
    //     showSecondsColumn: false,
    //     onChanged: (date) {
    //     }, onConfirm: (date) {
    // }, currentTime: DateTime.now());
    final TimeOfDay? timeOfDay = await showTimePicker(
      context: context,
      initialTime: time,
      initialEntryMode: TimePickerEntryMode.input,
    );
    if (timeOfDay != null && timeOfDay != time) {
      setState(() {
        time = timeOfDay;
      });
    }
  }
}
