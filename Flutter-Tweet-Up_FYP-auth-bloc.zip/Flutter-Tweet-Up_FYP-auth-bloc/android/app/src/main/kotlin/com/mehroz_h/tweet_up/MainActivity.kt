package com.mehroz_h.tweet_up

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
