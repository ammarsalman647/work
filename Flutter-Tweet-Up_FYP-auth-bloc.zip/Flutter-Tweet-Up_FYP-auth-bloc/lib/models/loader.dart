class Loading {
  String loading = '';
}
