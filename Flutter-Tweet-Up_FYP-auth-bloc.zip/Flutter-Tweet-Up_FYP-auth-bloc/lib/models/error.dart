class ErrorMsg {
  String error;
  ErrorMsg(this.error);
}
