class TeacherModel{
  String? classCode;
  String? batch;
}