

import 'package:flutter/material.dart';

class ThemeInitial {
  final ThemeData themeData;
  ThemeInitial({required this.themeData});
}
