import 'package:flutter/material.dart';

class ClassesViewModel extends ChangeNotifier{

  Future<void> teacherClasses() async{

    

  }
}