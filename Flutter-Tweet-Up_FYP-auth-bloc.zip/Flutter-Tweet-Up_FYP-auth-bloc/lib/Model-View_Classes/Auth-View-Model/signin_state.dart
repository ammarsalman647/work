part of 'signin_bloc.dart';

abstract class RegisterState extends Equatable {
  const RegisterState();
}

class SigninInitial extends RegisterState {
  @override
  List<Object> get props => [];
}
