import 'package:flutter/material.dart';

class ImageTesting extends StatefulWidget {
  const ImageTesting({super.key});

  @override
  State<ImageTesting> createState() => _ImageTestingState();
}

class _ImageTestingState extends State<ImageTesting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Image.asset('images/logo.png'));
  }
}
