import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:todo_app/my_button.dart';

class Dialog_Box extends StatelessWidget {
  final controller;
  VoidCallback  onSave;
  VoidCallback onCancel;
  Dialog_Box({super.key,
    required this.controller,
    required this.onCancel,
    required this.onSave
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.pink.shade100,
        content: Container(
      height: MediaQuery.of(context).size.height * .20,
      child: Column(
        children: [
          TextField(
            controller: controller,
            decoration: InputDecoration(
                border: OutlineInputBorder(), hintText: "Add a new task"),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
              MyButton(text: "Save", onPressed: onSave),
            MyButton(text: "Cancel", onPressed: onCancel),
          ],)
        ],
      ),
    ));
  }
}
